# Database Design

## 1. Introduction

## 2. Design Principles

## 3. Naming Conventions

## 4. Multi-Tenant Strategy

## 5. Audit Strategy

## 6. Soft Delete Strategy

## 7. Entity Relationship Diagram

## 8. Core Tables

### Business

### Business Settings

### Business WhatsApp

### Users

### Roles

### Customers

### Services

### Service Categories

### Slots

### Bookings

### Booking Status

### Conversation State

### Notifications

### Audit Logs

...

## 9. Index Strategy

## 10. Constraints

## 11. Foreign Keys

## 12. Performance Considerations

## 13. Future Tables

## Revision History
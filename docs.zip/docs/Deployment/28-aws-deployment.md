# AWS Deployment

**Document ID:** DEV-004  
**Project:** Appointment Platform (WhatsApp First SaaS)  
**Version:** 1.0  
**Status:** Draft

---

# Purpose

This document describes how the Appointment Platform is deployed on AWS using Docker, Kubernetes (EKS), Helm, GitHub Actions, PostgreSQL, Redis, and AWS managed services.

The objective is to provide a secure, scalable, and highly available production environment.

---

# Deployment Goals

- High Availability
- Auto Scaling
- Zero Downtime Deployment
- Secure Infrastructure
- Automated CI/CD
- Disaster Recovery
- Monitoring & Logging

---

# AWS Services Used

| Service | Purpose |
|----------|----------|
| EKS | Kubernetes Cluster |
| EC2 | Worker Nodes |
| ECR | Docker Image Repository |
| RDS PostgreSQL | Database |
| ElastiCache Redis | Cache |
| S3 | File Storage |
| CloudFront | CDN |
| Route53 | DNS |
| ACM | SSL Certificate |
| IAM | Access Management |
| Secrets Manager | Secrets Storage |
| CloudWatch | Monitoring & Logs |
| ALB | Application Load Balancer |
| WAF | Web Application Firewall |
| SNS | Notifications |
| SQS | Message Queue |

---

# AWS Architecture

```text
                Internet
                    │
                    ▼
              Route53 DNS
                    │
                    ▼
          AWS Certificate Manager
                    │
                    ▼
        Application Load Balancer
                    │
                    ▼
             Kubernetes (EKS)
        ┌──────────┼──────────┐
        ▼          ▼          ▼
 Backend Pod   Backend Pod   Backend Pod
        │
        ▼
      Redis
        │
        ▼
 PostgreSQL (RDS)
        │
        ▼
        S3
```

---

# Infrastructure Overview

```text
GitHub

↓

GitHub Actions

↓

Docker Image

↓

Amazon ECR

↓

Amazon EKS

↓

Application Running
```

---

# Deployment Components

## Backend

- Node.js
- Fastify
- TypeScript

Runs inside Kubernetes Pods.

---

## Frontend

- React
- TypeScript

Can be deployed

- Inside Kubernetes

OR

- S3 + CloudFront (Recommended)

---

## Database

Amazon RDS PostgreSQL

Benefits

- Automated Backup
- High Availability
- Read Replicas
- Automatic Patching

---

## Cache

Amazon ElastiCache Redis

Used for

- Session Storage
- API Cache
- Rate Limiting
- Background Jobs

---

## Object Storage

Amazon S3

Stores

- Images
- Documents
- Invoices
- Business Logos
- Exported Reports

---

# Kubernetes Deployment

Pods

```text
Backend Pods

Frontend Pods

Redis

Ingress Controller
```

Each pod can be automatically restarted if it fails.

---

# Auto Scaling

```text
High Traffic

↓

Kubernetes HPA

↓

Increase Pods

↓

Traffic Normal

↓

Reduce Pods
```

---

# Docker Images

Images are stored in

```text
Amazon ECR
```

Example

```text
appointment-platform/backend:1.0.0

appointment-platform/frontend:1.0.0
```

---

# Deployment Workflow

```text
Developer

↓

Push Code

↓

GitHub Actions

↓

Run Tests

↓

Build Docker Image

↓

Push Image to Amazon ECR

↓

Deploy using Helm

↓

Kubernetes Rolling Update

↓

Production Ready
```

---

# Environment Configuration

Environment Variables

```text
NODE_ENV

PORT

DATABASE_URL

REDIS_URL

JWT_SECRET

AWS_REGION

S3_BUCKET

WHATSAPP_ACCESS_TOKEN

META_VERIFY_TOKEN
```

Store secrets in

- AWS Secrets Manager
- Kubernetes Secrets

Never commit secrets to Git.

---

# Networking

```text
Internet

↓

Application Load Balancer

↓

Ingress Controller

↓

Backend Pods
```

Private Resources

- PostgreSQL
- Redis

Public Resources

- Load Balancer
- CloudFront

---

# SSL

SSL Certificates managed by

```text
AWS Certificate Manager (ACM)
```

All traffic uses HTTPS.

---

# Domain Configuration

Example

```text
app.company.com

↓

Route53

↓

Load Balancer

↓

Application
```

---

# Database Deployment

Amazon RDS

Recommended

- PostgreSQL 16
- Multi-AZ
- Automatic Backup
- Encryption Enabled

---

# Backup Strategy

Daily

- Database Backup
- S3 Backup

Weekly

- Full Snapshot

Monthly

- Long-term Archive

---

# Logging

Application Logs

↓

CloudWatch Logs

System Logs

↓

CloudWatch

Audit Logs

↓

Database

---

# Monitoring

CloudWatch monitors

- CPU
- Memory
- Network
- Pod Health
- Database
- Redis
- API Errors
- Response Time

---

# Health Checks

Backend

```text
GET /health
```

Response

```json
{
  "status": "UP"
}
```

Kubernetes uses this endpoint for

- Liveness Probe
- Readiness Probe

---

# Security

Authentication

- JWT

Authorization

- Role Based Access Control (RBAC)

Infrastructure Security

- IAM Roles
- Security Groups
- Private Subnets
- WAF
- HTTPS Only
- Encrypted Storage

---

# Disaster Recovery

Plan

```text
Database Failure

↓

Restore Backup

↓

Restart Application

↓

Resume Service
```

Recovery Objectives

| Metric | Target |
|----------|---------|
| RPO | 15 Minutes |
| RTO | 30 Minutes |

---

# Production Deployment Strategy

Recommended

Rolling Deployment

```text
Old Pods

↓

New Pods

↓

Traffic Shift

↓

Old Pods Removed
```

Benefits

- Zero Downtime
- Easy Rollback
- Stable Releases

---

# Rollback Strategy

```text
Deployment Failed

↓

Helm Rollback

↓

Previous Version Restored
```

---

# CI/CD Integration

GitHub Actions

↓

Docker Build

↓

Amazon ECR

↓

Helm Upgrade

↓

Amazon EKS

↓

Production

---

# Cost Optimization

- Use Auto Scaling
- Use Spot Instances (Non-production)
- Delete unused ECR images
- Configure S3 lifecycle rules
- Monitor AWS Cost Explorer

---

# Performance Optimization

- CloudFront CDN
- Redis Cache
- Database Indexes
- Horizontal Pod Autoscaling
- Connection Pooling
- Image Compression

---

# Production Checklist

- HTTPS Enabled
- SSL Certificate Installed
- Secrets Configured
- Backups Enabled
- Monitoring Enabled
- Auto Scaling Enabled
- Health Checks Configured
- Logging Enabled
- WAF Enabled
- Alerts Configured

---

# Future Enhancements

- Multi-Region Deployment
- Blue-Green Deployment
- Canary Releases
- AWS X-Ray Tracing
- AWS OpenSearch
- EventBridge Integration
- Lambda Background Jobs
- Multi-Tenant Scaling

---

# Related Documents

- 25-development-guidelines.md
- 26-docker.md
- 27-github-actions.md
- 29-production-readiness.md
- 28.1-helm-deployment.md
- 28.2-kubernetes-architecture.md

---

# Revision History

| Version | Date | Description |
|----------|------|-------------|
| 1.0 | July 2026 | Initial AWS Deployment Documentation |
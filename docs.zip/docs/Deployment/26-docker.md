# Docker

**Document ID:** DEV-002  
**Project:** Appointment Platform (WhatsApp First SaaS)  
**Version:** 1.0  
**Status:** Draft

---

# Purpose

This document defines the Docker strategy for developing, testing, and deploying the Appointment Platform.

Docker ensures every developer works in the same environment, eliminating "works on my machine" issues.

---

# Objectives

- Standardized development environment
- Easy onboarding
- Isolated services
- Consistent deployments
- Faster development
- Simplified dependency management

---

# Scope

This document covers

- Docker Architecture
- Docker Images
- Docker Containers
- Docker Compose
- Development Environment
- Production Strategy
- Best Practices

---

# Why Docker?

Without Docker

```text
Developer A

Node 22

↓

Works
```

```text
Developer B

Node 20

↓

Fails
```

With Docker

```text
Docker Image

↓

Developer A

↓

Developer B

↓

CI/CD

↓

Production
```

Same environment everywhere.

---

# Docker Architecture

```text
Developer

↓

Docker Compose

↓

Backend Container

↓

Frontend Container

↓

PostgreSQL Container

↓

Redis Container
```

---

# Project Structure

```text
appointment-platform/

backend/

Dockerfile

frontend/

Dockerfile

docker-compose.yml

.env

README.md
```

---

# Containers

| Container | Purpose |
|------------|----------|
| Backend | Fastify API |
| Frontend | React Application |
| PostgreSQL | Database |
| Redis | Cache & Sessions |

---

# Backend Dockerfile

```dockerfile
FROM node:22-alpine

WORKDIR /app

COPY package*.json ./

RUN npm install

COPY . .

RUN npm run build

EXPOSE 3000

CMD ["npm", "run", "start"]
```

---

# Frontend Dockerfile

```dockerfile
FROM node:22-alpine

WORKDIR /app

COPY package*.json ./

RUN npm install

COPY . .

EXPOSE 5173

CMD ["npm", "run", "dev"]
```

---

# Docker Compose

```yaml
version: "3.9"

services:

  backend:
    build: ./backend
    ports:
      - "3000:3000"

  frontend:
    build: ./frontend
    ports:
      - "5173:5173"

  postgres:
    image: postgres:16

  redis:
    image: redis:7
```

---

# Local Development Flow

```text
Clone Repository

↓

Create .env

↓

docker compose up

↓

Containers Start

↓

Application Ready
```

---

# Environment Variables

Store configuration in

```text
.env
```

Example

```text
DATABASE_URL=postgresql://postgres:password@postgres:5432/appointment

PORT=3000

JWT_SECRET=my-secret

REDIS_URL=redis://redis:6379
```

Do not commit `.env` to Git.

---

# Volumes

Use volumes to persist database data.

Example

```yaml
volumes:

  postgres-data:
```

Benefits

- Database survives container restart
- Easy local backups
- Faster development

---

# Networks

Docker creates a private network.

Communication

```text
Frontend

↓

Backend

↓

PostgreSQL

↓

Redis
```

Containers communicate using service names.

Example

```text
postgres

redis

backend
```

---

# Build Process

```text
Docker Build

↓

Create Image

↓

Run Container
```

Command

```bash
docker compose build
```

---

# Start Containers

```bash
docker compose up
```

Detached mode

```bash
docker compose up -d
```

---

# Stop Containers

```bash
docker compose down
```

---

# View Logs

```bash
docker compose logs
```

Backend logs

```bash
docker compose logs backend
```

---

# Rebuild Containers

```bash
docker compose up --build
```

---

# Common Docker Commands

| Command | Purpose |
|----------|----------|
| docker compose up | Start containers |
| docker compose down | Stop containers |
| docker compose build | Build images |
| docker compose ps | View running containers |
| docker compose logs | View logs |
| docker compose restart | Restart services |
| docker compose exec backend sh | Open backend shell |

---

# Development Workflow

```text
Developer

↓

Code Changes

↓

Docker Container

↓

Auto Reload

↓

Browser
```

---

# Database Migrations

Run Prisma migrations inside the backend container.

```bash
docker compose exec backend npx prisma migrate dev
```

---

# Seed Database

```bash
docker compose exec backend npm run seed
```

---

# Health Checks

Each container should expose a health endpoint.

Backend

```text
GET /health
```

Response

```json
{
  "status": "UP"
}
```

---

# Security Best Practices

- Use official Docker images.
- Keep images updated.
- Do not run containers as root.
- Never store secrets inside Docker images.
- Use environment variables for credentials.
- Scan images for vulnerabilities.

---

# Performance Best Practices

- Use lightweight images (Alpine).
- Cache dependencies during build.
- Use multi-stage builds for production.
- Minimize image size.
- Remove unused packages.

---

# Production Deployment

```text
Developer

↓

GitHub

↓

GitHub Actions

↓

Docker Image

↓

Container Registry

↓

Kubernetes

↓

Production
```

Docker creates the application image, while Kubernetes runs and manages the containers in production.

---

# Troubleshooting

Common Issues

| Problem | Solution |
|----------|----------|
| Port already in use | Change port or stop conflicting service |
| Database connection failed | Check DATABASE_URL and PostgreSQL container |
| Container exits immediately | Review container logs |
| Changes not reflected | Rebuild image or check volume mounts |
| Prisma migration failed | Verify database connection |

---

# Best Practices

- One service per container.
- Keep images small.
- Use Docker Compose for local development.
- Never commit `.env` files.
- Use named volumes for databases.
- Rebuild images after dependency changes.
- Tag images with application version.

---

# Future Enhancements

- Multi-stage Docker builds
- Docker image scanning
- Private container registry
- Docker Build Cache
- Development hot reload optimization
- Production image optimization

---

# Related Documents

- 25-development-guidelines.md
- 27-github-actions.md
- 28-aws-deployment.md
- 29-production-readiness.md
- 07-database-design.md

---

# Revision History

| Version | Date | Description |
|----------|------|-------------|
| 1.0 | July 2026 | Initial Docker Documentation |
# Role & Permission

**Document ID:** FE-004  
**Project:** Appointment Platform (WhatsApp First SaaS)  
**Version:** 1.0  
**Status:** Draft

---

# Purpose

This document defines the Role-Based Access Control (RBAC) model for the Appointment Platform.

The objective is to ensure that every user can access only the features and data required for their role.

---

# Objectives

- Secure system access
- Role-based authorization
- Multi-tenant security
- Easy permission management
- Support future custom roles
- Prevent unauthorized access

---

# Scope

This document covers

- User Roles
- Permissions
- Access Levels
- Authorization Rules
- Role Hierarchy
- Future Custom Roles

---

# RBAC Architecture

```text
User

↓

Login

↓

Authentication (JWT)

↓

Authorization

↓

Role Verification

↓

Permission Verification

↓

Access Granted / Denied
```

---

# Default Roles

| Role | Description |
|------|-------------|
| Super Admin | Complete platform management |
| Business Owner | Own business management |
| Manager | Business operations |
| Receptionist | Booking management |
| Staff | Limited operational access |

---

# Role Hierarchy

```text
Super Admin

↓

Business Owner

↓

Manager

↓

Receptionist

↓

Staff
```

---

# Super Admin

Responsibilities

- Manage all businesses
- Manage subscriptions
- Manage platform settings
- View all reports
- Manage users
- Monitor system health
- Access all data

---

# Business Owner

Responsibilities

- Manage own business
- Manage bookings
- Manage services
- Manage customers
- Manage business users
- Configure WhatsApp
- View reports
- Manage subscription

---

# Manager

Responsibilities

- Manage bookings
- Manage customers
- Manage services
- Manage slots
- View reports
- Approve bookings

Cannot

- Manage subscription
- Delete business
- Change WhatsApp credentials

---

# Receptionist

Responsibilities

- View bookings
- Create bookings
- Cancel bookings
- Reschedule bookings
- View customers

Cannot

- Delete services
- Manage users
- Change business settings
- Access subscription

---

# Staff

Responsibilities

- View assigned appointments
- Update appointment status

Cannot

- Manage customers
- Manage services
- Manage business settings
- View reports
- Access WhatsApp settings

---

# Permission Types

| Permission | Description |
|------------|-------------|
| View | Read-only access |
| Create | Create new records |
| Update | Modify existing records |
| Delete | Delete records |
| Approve | Approve requests |
| Export | Export data |
| Configure | Change settings |

---

# Module Permissions

| Module | Super Admin | Owner | Manager | Receptionist | Staff |
|---------|-------------|--------|----------|--------------|-------|
| Dashboard | CRUD | CRUD | CRUD | View | View |
| Bookings | CRUD | CRUD | CRUD | CRUD | View |
| Customers | CRUD | CRUD | CRUD | View | View |
| Services | CRUD | CRUD | CRUD | View | View |
| Slots | CRUD | CRUD | CRUD | View | View |
| Reports | CRUD | View | View | No | No |
| WhatsApp Settings | CRUD | CRUD | No | No | No |
| Business Settings | CRUD | CRUD | View | No | No |
| Users | CRUD | CRUD | View | No | No |
| Subscription | CRUD | CRUD | No | No | No |

---

# Booking Permissions

| Action | Owner | Manager | Receptionist | Staff |
|---------|--------|----------|--------------|-------|
| View Booking | ✅ | ✅ | ✅ | ✅ |
| Create Booking | ✅ | ✅ | ✅ | ❌ |
| Approve Booking | ✅ | ✅ | ❌ | ❌ |
| Reject Booking | ✅ | ✅ | ❌ | ❌ |
| Cancel Booking | ✅ | ✅ | ✅ | ❌ |
| Delete Booking | ✅ | ❌ | ❌ | ❌ |

---

# Customer Permissions

| Action | Owner | Manager | Receptionist | Staff |
|---------|--------|----------|--------------|-------|
| View | ✅ | ✅ | ✅ | ✅ |
| Create | ✅ | ✅ | ✅ | ❌ |
| Update | ✅ | ✅ | ❌ | ❌ |
| Delete | ✅ | ❌ | ❌ | ❌ |

---

# Service Permissions

| Action | Owner | Manager | Receptionist | Staff |
|---------|--------|----------|--------------|-------|
| View | ✅ | ✅ | ✅ | ✅ |
| Create | ✅ | ✅ | ❌ | ❌ |
| Update | ✅ | ✅ | ❌ | ❌ |
| Delete | ✅ | ❌ | ❌ | ❌ |

---

# Slot Permissions

| Action | Owner | Manager | Receptionist | Staff |
|---------|--------|----------|--------------|-------|
| View | ✅ | ✅ | ✅ | ✅ |
| Create | ✅ | ✅ | ❌ | ❌ |
| Update | ✅ | ✅ | ❌ | ❌ |
| Delete | ✅ | ❌ | ❌ | ❌ |

---

# User Management Permissions

| Action | Super Admin | Owner | Manager |
|---------|-------------|--------|----------|
| Create User | ✅ | ✅ | ❌ |
| Update User | ✅ | ✅ | ❌ |
| Delete User | ✅ | ✅ | ❌ |
| Reset Password | ✅ | ✅ | ❌ |
| Assign Role | ✅ | ✅ | ❌ |

---

# Authorization Flow

```text
User Login

↓

JWT Token

↓

Extract User Role

↓

Check Required Permission

↓

Access Granted

OR

Access Denied
```

---

# Multi-Tenant Security

Every business can access only its own data.

Example

```text
Business A

↓

Bookings

Customers

Services

Users
```

Cannot access

```text
Business B Data
```

---

# Permission Storage

Suggested Tables

```text
roles

permissions

role_permissions

users
```

---

# Sample Permissions

```text
BOOKING_VIEW

BOOKING_CREATE

BOOKING_UPDATE

BOOKING_DELETE

SERVICE_CREATE

CUSTOMER_VIEW

REPORT_VIEW

USER_MANAGEMENT

WHATSAPP_CONFIGURATION
```

---

# Access Denied Response

If permission is missing

Return

```text
403 Forbidden
```

Message

```text
You do not have permission to perform this action.
```

---

# Audit Logging

Log every sensitive action

- Login
- Logout
- Create User
- Delete User
- Booking Approval
- Business Settings Change
- WhatsApp Configuration Change
- Subscription Change

---

# Security Rules

- Every API must validate JWT.
- Every API must verify user role.
- Every API must check permissions.
- Never trust frontend permissions.
- Authorization must always happen on the backend.

---

# Future Enhancements

- Custom Roles
- Permission Groups
- Temporary Permissions
- Approval Workflow
- Two-Factor Authentication (2FA)
- Single Sign-On (SSO)
- Audit Dashboard

---

# Related Documents

- 11-authentication.md
- 12-authorization.md
- 21-admin-web-application.md
- 22-screen-design.md
- 23-navigation.md

---

# Revision History

| Version | Date | Description |
|----------|------|-------------|
| 1.0 | July 2026 | Initial Role & Permission Design |
# Screen Design

**Document ID:** FE-002  
**Project:** Appointment Platform (WhatsApp First SaaS)  
**Version:** 1.0  
**Status:** Draft

---

# Purpose

This document defines all screens of the Admin Web Application.

The objective is to provide a simple, clean, and user-friendly interface for business owners and staff to manage appointments, customers, services, and business settings.

---

# Design Principles

- Simple UI
- Mobile Responsive
- Fast Navigation
- Minimal Clicks
- Clean Layout
- Consistent Components

---

# Application Layout

```text
+------------------------------------------------------+
| Header                                                |
+------------+-----------------------------------------+
|            |                                         |
| Sidebar    |         Main Content                    |
|            |                                         |
|            |                                         |
+------------+-----------------------------------------+
| Footer                                               |
+------------------------------------------------------+
```

---

# Screen List

| Screen | Purpose |
|----------|---------|
| Login | User Login |
| Dashboard | Business Overview |
| Bookings | Manage Appointments |
| Booking Details | View Appointment |
| Customers | Customer Management |
| Customer Details | Customer Profile |
| Services | Manage Services |
| Service Form | Add/Edit Service |
| Slots | Manage Slots |
| Slot Form | Add/Edit Slots |
| WhatsApp Settings | WhatsApp Configuration |
| Business Settings | Business Information |
| Reports | Business Reports |
| Notifications | Notification History |
| Subscription | Plan Details |
| Profile | User Profile |

---

# 1. Login Screen

Purpose

Business user authentication.

Fields

- Email
- Password

Buttons

- Login
- Forgot Password

Layout

```text
-----------------------------

Appointment Platform

Email

_____________

Password

_____________

[ Login ]

Forgot Password

-----------------------------
```

---

# 2. Dashboard

Purpose

Business summary.

Widgets

- Today's Bookings
- Pending Bookings
- Completed Bookings
- Cancelled Bookings
- Customers
- Services
- Upcoming Appointments

Layout

```text
-----------------------------------

Dashboard

Today's Bookings

Pending

Completed

Cancelled

-----------------------------------

Upcoming Appointments

Recent Activity

-----------------------------------
```

---

# 3. Bookings Screen

Purpose

Manage appointments.

Functions

- Search
- Filter
- Approve
- Reject
- Cancel
- View Details

Columns

- Booking ID
- Customer
- Service
- Date
- Time
- Status
- Actions

---

# 4. Booking Details

Display

- Customer
- Service
- Date
- Slot
- Status
- Notes

Buttons

- Approve
- Reject
- Cancel
- Reschedule

---

# 5. Customers

Purpose

Customer management.

Columns

- Name
- Mobile
- Total Bookings
- Last Visit
- Status

Actions

- View
- Edit
- Booking History

---

# 6. Customer Details

Display

- Name
- Mobile Number
- Booking History
- Notes

Future

- Loyalty Points
- Membership

---

# 7. Services

Purpose

Manage services.

Columns

- Service Name
- Duration
- Price
- Status

Buttons

- Add Service
- Edit
- Delete

---

# 8. Add/Edit Service

Fields

- Service Name
- Description
- Duration
- Price
- Status

Buttons

- Save
- Cancel

---

# 9. Slots

Purpose

Manage appointment slots.

Functions

- Create Slot
- Delete Slot
- Block Slot
- Bulk Create

Columns

- Date
- Start Time
- End Time
- Capacity
- Status

---

# 10. Add/Edit Slot

Fields

- Date
- Start Time
- End Time
- Capacity
- Service
- Status

Buttons

- Save
- Cancel

---

# 11. WhatsApp Settings

Fields

- Business Phone Number
- Phone Number ID
- Access Token
- Verify Token
- Webhook URL
- Auto Approval
- Reminder Enabled

Buttons

- Save
- Test Connection

---

# 12. Business Settings

Fields

- Business Name
- Logo
- Address
- Email
- Mobile Number
- Time Zone
- Working Hours

Buttons

- Save

---

# 13. Reports

Available Reports

- Daily Bookings
- Monthly Bookings
- Customer Report
- Service Report
- Cancellation Report

Future

- Revenue Report
- Staff Report

---

# 14. Notification History

Display

- Date
- Recipient
- Notification Type
- Delivery Status

Filters

- Date
- Status

---

# 15. Subscription

Display

- Current Plan
- Expiry Date
- Active Users
- WhatsApp Messages Used

Buttons

- Upgrade Plan
- Renew Subscription

---

# 16. Profile

Fields

- Name
- Email
- Mobile Number
- Change Password

Buttons

- Save

---

# Common UI Components

- Sidebar
- Top Navigation
- Data Table
- Search Box
- Filter Panel
- Pagination
- Modal Dialog
- Confirmation Dialog
- Toast Notification
- Loading Spinner

---

# Form Validation

Validate

- Required fields
- Email format
- Mobile number
- Duplicate service names
- Duplicate slots
- Invalid dates

Display validation messages below the field.

---

# Color Guidelines

| Status | Suggested Color |
|----------|----------------|
| Success | Green |
| Pending | Orange |
| Cancelled | Red |
| Completed | Blue |
| Disabled | Gray |

---

# Responsive Design

Support

- Desktop
- Laptop
- Tablet
- Mobile

Sidebar collapses automatically on smaller screens.

---

# Accessibility

- Keyboard navigation
- Proper labels
- High contrast
- Screen reader support
- Focus indicators

---

# Future Screens

- Staff Management
- Branch Management
- Holiday Calendar
- Coupons
- Reviews
- Analytics Dashboard
- AI Assistant
- Payment History
- Audit Logs

---

# Related Documents

- 21-admin-web-application.md
- 23-navigation.md
- 24-role-permission.md
- 10-api-design.md

---

# Revision History

| Version | Date | Description |
|----------|------|-------------|
| 1.0 | July 2026 | Initial Screen Design |
# Navigation

**Document ID:** FE-003  
**Project:** Appointment Platform (WhatsApp First SaaS)  
**Version:** 1.0  
**Status:** Draft

---

# Purpose

This document defines the navigation structure of the Admin Web Application.

The goal is to provide a simple, intuitive, and consistent navigation experience for business users.

---

# Objectives

- Easy navigation
- Minimum clicks
- Consistent layout
- Mobile-friendly
- Role-based menu
- Fast access to common features

---

# Navigation Layout

```text
+------------------------------------------------------------+
| Header                                                     |
+------------+-----------------------------------------------+
|            |                                               |
| Sidebar    |             Main Content                      |
|            |                                               |
|            |                                               |
+------------+-----------------------------------------------+
```

---

# Navigation Components

- Header
- Sidebar
- Breadcrumb
- User Menu
- Footer

---

# Header

The header contains

- Application Logo
- Business Name
- Notification Icon
- Profile Menu
- Logout Button

Layout

```text
-------------------------------------------------------------

Logo

Appointment Platform

Notifications

Business Name

Profile ▼

-------------------------------------------------------------
```

---

# Sidebar Menu

```text
Dashboard

Bookings

Customers

Services

Slots

Reports

WhatsApp

Settings

Subscription

Profile

Logout
```

---

# Dashboard Navigation

```text
Dashboard

↓

Today's Bookings

↓

Booking Details
```

---

# Booking Navigation

```text
Bookings

↓

Booking List

↓

Booking Details

↓

Approve Booking

↓

Reject Booking

↓

Cancel Booking

↓

Back to Booking List
```

---

# Customer Navigation

```text
Customers

↓

Customer List

↓

Customer Details

↓

Booking History
```

---

# Service Navigation

```text
Services

↓

Service List

↓

Add Service

↓

Edit Service

↓

Delete Service
```

---

# Slot Navigation

```text
Slots

↓

Slot List

↓

Add Slot

↓

Edit Slot

↓

Delete Slot
```

---

# Reports Navigation

```text
Reports

↓

Daily Report

Monthly Report

Customer Report

Service Report

Cancellation Report
```

---

# WhatsApp Navigation

```text
WhatsApp

↓

Connection Settings

↓

Webhook Settings

↓

Message Templates

↓

Reminder Settings

↓

Notification History
```

---

# Settings Navigation

```text
Settings

↓

Business Settings

↓

Working Hours

↓

Holiday Calendar

↓

Users

↓

Roles

↓

Permissions
```

---

# Subscription Navigation

```text
Subscription

↓

Current Plan

↓

Usage

↓

Billing History

↓

Upgrade Plan
```

---

# Profile Navigation

```text
Profile

↓

Personal Information

↓

Change Password

↓

Notification Preferences
```

---

# Breadcrumb Navigation

Example

```text
Dashboard

>

Bookings

>

Booking Details
```

Another Example

```text
Dashboard

>

Services

>

Add Service
```

---

# Mobile Navigation

On mobile devices

- Sidebar becomes collapsible
- Hamburger menu opens sidebar
- Header remains fixed

Layout

```text
☰

Appointment Platform

🔔

👤
```

---

# Quick Actions

Dashboard should provide quick action buttons.

Examples

```text
+ Add Booking

+ Add Customer

+ Add Service

+ Create Slot
```

---

# Search Navigation

Global search allows users to search

- Bookings
- Customers
- Services

Results should navigate directly to the selected record.

---

# Notifications

Clicking the notification icon opens

```text
New Booking

Booking Approved

Reminder Failed

Subscription Expiring
```

Selecting a notification navigates to the related screen.

---

# Navigation Rules

- Dashboard is the default landing page after login.
- Sidebar remains visible on desktop.
- Current menu item should be highlighted.
- Breadcrumbs should appear on every page except Login.
- Clicking the logo always returns to the Dashboard.

---

# Role-Based Navigation

| Menu | Super Admin | Owner | Manager | Receptionist | Staff |
|------|-------------|--------|----------|--------------|-------|
| Dashboard | ✅ | ✅ | ✅ | ✅ | ✅ |
| Bookings | ✅ | ✅ | ✅ | ✅ | View Only |
| Customers | ✅ | ✅ | ✅ | ✅ | View Only |
| Services | ✅ | ✅ | ✅ | View | View |
| Slots | ✅ | ✅ | ✅ | View | View |
| Reports | ✅ | ✅ | View | ❌ | ❌ |
| WhatsApp Settings | ✅ | ✅ | ❌ | ❌ | ❌ |
| Business Settings | ✅ | ✅ | ❌ | ❌ | ❌ |
| Subscription | ✅ | ✅ | ❌ | ❌ | ❌ |
| Profile | ✅ | ✅ | ✅ | ✅ | ✅ |

---

# Error Navigation

If a page cannot be accessed

Display

```text
403

Access Denied
```

If the page does not exist

Display

```text
404

Page Not Found
```

If the server is unavailable

Display

```text
500

Internal Server Error
```

---

# Future Navigation

Future menu items

```text
Dashboard

Bookings

Customers

Services

Slots

Staff

Branches

Calendar

Payments

Coupons

Reviews

Reports

Analytics

AI Assistant

Settings
```

---

# Performance Requirements

| Feature | Target |
|----------|---------|
| Page Navigation | < 1 sec |
| Sidebar Load | < 200 ms |
| Breadcrumb Update | < 100 ms |
| Search Result | < 500 ms |

---

# Accessibility

- Keyboard navigation
- Visible focus indicator
- Screen reader support
- Proper menu labels
- Responsive design

---

# Related Documents

- 21-admin-web-application.md
- 22-screen-design.md
- 24-role-permission.md
- 11-authentication.md
- 12-authorization.md

---

# Revision History

| Version | Date | Description |
|----------|------|-------------|
| 1.0 | July 2026 | Initial Navigation Design |
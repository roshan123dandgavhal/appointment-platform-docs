# Admin Web Application

**Document ID:** FE-001  
**Project:** Appointment Platform (WhatsApp First SaaS)  
**Version:** 1.0  
**Status:** Draft

---

# Purpose

The Admin Web Application is the central management portal for businesses using the Appointment Platform.

While customers interact through WhatsApp, business owners and staff use the web application to manage their business, appointments, customers, services, settings, reports, and WhatsApp integration.

---

# Objectives

- Simple and responsive UI
- Multi-tenant architecture
- Secure authentication
- Easy business management
- Mobile-friendly design
- Fast loading screens

---

# Scope

Business users can manage

- Dashboard
- Bookings
- Customers
- Services
- Slots
- Staff (Future)
- Branches (Future)
- WhatsApp Settings
- Business Settings
- Reports
- Notifications
- Subscription

---

# Target Users

| Role | Access |
|------|---------|
| Super Admin | Complete platform access |
| Business Owner | Own business only |
| Manager | Business management |
| Receptionist | Booking management |
| Staff | Limited access |

---

# Technology Stack

| Component | Technology |
|-----------|------------|
| Framework | React |
| Language | TypeScript |
| UI Library | Material UI (MUI) |
| API | Fastify Backend |
| Authentication | JWT |
| State Management | React Query + Context API |
| Forms | React Hook Form |
| Charts | Recharts (Future) |

---

# High Level Architecture

```text
Business User

        │

        ▼

React Web Application

        │

        ▼

REST API

        │

        ▼

Fastify Backend

        │

        ▼

PostgreSQL
```

---

# Application Modules

```text
Dashboard

Bookings

Customers

Services

Slots

Business Settings

WhatsApp Settings

Reports

Notifications

Subscription

Profile
```

---

# Login Flow

```text
User

↓

Login Page

↓

Enter Email

↓

Enter Password

↓

JWT Authentication

↓

Dashboard
```

---

# Main Navigation

```text
Dashboard

Bookings

Customers

Services

Slots

Reports

WhatsApp

Settings

Profile

Logout
```

---

# Dashboard

The Dashboard displays

- Today's Bookings
- Pending Approvals
- Completed Appointments
- Cancelled Appointments
- Revenue (Future)
- New Customers
- Upcoming Appointments

---

# Booking Management

Business users can

- View bookings
- Search bookings
- Filter bookings
- Approve booking
- Reject booking
- Cancel booking
- Reschedule booking
- View booking details

---

# Customer Management

Business users can

- View customers
- Search customers
- Booking history
- Customer profile
- Add notes
- Block customer (Future)

---

# Service Management

Business users can

- Create service
- Edit service
- Delete service
- Enable service
- Disable service
- Configure duration
- Configure pricing

---

# Slot Management

Business users can

- Create slots
- Edit slots
- Delete slots
- Block slots
- Bulk slot creation
- Holiday management

---

# WhatsApp Settings

Business users can configure

- WhatsApp Business Account
- Access Token
- Phone Number ID
- Webhook Verification Token
- Auto Reply
- Auto Approval
- Reminder Settings

---

# Business Settings

Business users can configure

- Business Name
- Logo
- Address
- Contact Number
- Working Hours
- Holidays
- Time Zone
- Currency

---

# Reports

Available Reports

- Daily Bookings
- Monthly Bookings
- Customer Report
- Service Report
- Cancellation Report
- Reminder Report

Future

- Revenue Report
- Staff Performance
- Business Analytics

---

# Notifications

Business users receive notifications for

- New Booking
- Booking Approval Required
- Booking Cancelled
- Reminder Failed
- WhatsApp Connection Failed
- Subscription Expiry

---

# Subscription

Business users can

- View current plan
- Upgrade plan
- Renew subscription
- View invoices
- Payment history

---

# User Profile

Users can

- Update profile
- Change password
- Enable 2FA (Future)
- Update notification preferences

---

# Responsive Design

Supported Devices

| Device | Supported |
|----------|-----------|
| Desktop | ✅ |
| Laptop | ✅ |
| Tablet | ✅ |
| Mobile | ✅ |

---

# Security

The Admin Web Application must

- Require login
- Use JWT authentication
- Implement Role-Based Access Control (RBAC)
- Automatically expire sessions
- Use HTTPS only
- Validate all user inputs

---

# Performance Requirements

| Feature | Target |
|----------|---------|
| Login | < 2 sec |
| Dashboard Load | < 2 sec |
| API Response | < 500 ms |
| Page Navigation | < 1 sec |

---

# Error Handling

Display friendly error messages for

- Login failure
- Network failure
- Validation errors
- Unauthorized access
- Server errors

Example

```text
Something went wrong.

Please try again later.
```

---

# Future Enhancements

- Dark Mode
- Multi-language Support
- Drag & Drop Dashboard
- Mobile Application
- Offline Support
- AI Business Insights
- Voice Commands
- Calendar View
- Staff Management
- Multi-Branch Management

---

# Related Documents

- 22-screen-design.md
- 23-navigation.md
- 24-role-permission.md
- 10-api-design.md
- 11-authentication.md
- 12-authorization.md
- 28-aws-deployment.md

---

# Revision History

| Version | Date | Description |
|----------|------|-------------|
| 1.0 | July 2026 | Initial Admin Web Application Design |
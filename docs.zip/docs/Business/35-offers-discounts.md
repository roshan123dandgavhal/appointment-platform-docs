# Offers & Discounts

**Document ID:** BIZ-003  
**Project:** Appointment Platform (WhatsApp First SaaS)  
**Version:** 1.0  
**Status:** Draft

---

# Purpose

This document defines the Offers and Discounts module for the Appointment Platform.

The objective is to help businesses attract new customers, retain existing customers, and increase bookings through promotional campaigns.

---

# Objectives

- Increase customer bookings
- Improve customer retention
- Support promotional campaigns
- Encourage repeat visits
- Enable flexible discount rules
- Increase business revenue

---

# Scope

This document covers

- Discount Types
- Offer Management
- Coupon Codes
- Promotional Campaigns
- Referral Rewards
- Loyalty Discounts
- Birthday Offers
- Festival Offers
- Usage Rules
- Reporting

---

# Offer Types

Supported offers

- Percentage Discount
- Flat Discount
- Buy One Get One (Future)
- Free Service
- Combo Offer
- Loyalty Reward
- Referral Reward
- Seasonal Offer
- First Booking Discount

---

# Discount Types

## Percentage Discount

Example

```text
20% OFF

Maximum Discount ₹500
```

---

## Flat Discount

Example

```text
₹200 OFF

On bookings above ₹1,000
```

---

## Free Service

Example

```text
Free Hair Wash

With Haircut
```

---

## Combo Offer

Example

```text
Haircut + Beard

₹699
```

---

# Coupon Codes

Examples

- WELCOME10
- FIRST50
- SUMMER2026
- FESTIVE20
- REFER100

Coupons can be entered during booking.

---

# Coupon Configuration

Each coupon contains

| Field | Description |
|----------|-------------|
| Coupon Code | Unique code |
| Offer Name | Promotion name |
| Discount Type | Percentage / Flat |
| Discount Value | Amount or Percentage |
| Maximum Discount | Optional |
| Minimum Booking Value | Optional |
| Start Date | Offer start |
| End Date | Offer expiry |
| Active Status | Enabled / Disabled |

---

# Eligibility Rules

Discounts may apply based on

- First Booking
- Returning Customer
- Specific Services
- Specific Staff
- Booking Value
- Booking Date
- Customer Category

---

# First Booking Offer

Example

```text
20% OFF

Applicable only to the customer's first appointment.
```

---

# Referral Program

Workflow

```text
Customer A

↓

Shares Referral Code

↓

Customer B Registers

↓

Customer B Completes First Booking

↓

Customer A Receives Reward

↓

Customer B Receives Discount
```

---

# Loyalty Rewards

Reward customers based on

- Number of bookings
- Amount spent
- Membership duration

Example

| Bookings Completed | Reward |
|--------------------|--------|
| 5 | 10% Discount |
| 10 | ₹500 Voucher |
| 20 | Free Service |

---

# Birthday Offers

Automatically send

- Birthday wishes
- Birthday coupon
- Limited-time discount

Example

```text
Happy Birthday!

Enjoy 25% OFF this week.
```

---

# Anniversary Offers

Applicable for

- Customer registration anniversary
- Business anniversary campaigns

---

# Festival Campaigns

Examples

- Diwali Sale
- Christmas Offer
- New Year Discount
- Holi Special
- Independence Day Offer

Campaigns can be scheduled in advance.

---

# Time-Based Offers

Examples

- Weekend Offer
- Monday Discount
- Happy Hours
- Morning Discount

Example

```text
20% OFF

Monday to Friday

10:00 AM – 1:00 PM
```

---

# Service-Based Offers

Offer applicable only to selected services.

Example

- Haircut
- Spa
- Massage
- Facial

---

# Business Rules

- Coupon must be active.
- Coupon must not be expired.
- Customer must meet eligibility rules.
- Coupon usage limits must not be exceeded.
- Only one coupon can be applied per booking (configurable).

---

# Usage Limits

Support

- Single Use
- Multiple Use
- One Use Per Customer
- Limited Total Redemptions

Example

| Coupon | Maximum Uses |
|----------|--------------|
| FIRST50 | 1 per customer |
| SUMMER20 | 1,000 total |
| VIP25 | Unlimited |

---

# Coupon Validation Flow

```text
Customer Applies Coupon

↓

Coupon Exists?

↓

Valid Date?

↓

Eligible Customer?

↓

Booking Amount Valid?

↓

Apply Discount

↓

Booking Confirmed
```

---

# Discount Calculation

Example

Booking Amount

```text
₹2,000
```

Coupon

```text
20% OFF

Maximum ₹300
```

Calculation

```text
20% of ₹2,000 = ₹400

Maximum Allowed = ₹300

Final Discount = ₹300

Customer Pays = ₹1,700
```

---

# WhatsApp Promotions

Promotional messages can be sent through WhatsApp.

Examples

- New Offers
- Festival Discounts
- Birthday Wishes
- Loyalty Rewards
- Referral Campaigns

Messages should use approved WhatsApp templates where required.

---

# Offer Dashboard

Business owners can view

- Active Offers
- Expired Offers
- Coupon Usage
- Revenue Generated
- Redemption Rate
- Top Performing Campaigns

---

# Reports

Generate reports for

- Coupon Usage
- Offer Performance
- Revenue Impact
- Redemption History
- Customer Participation
- Referral Statistics

---

# Database Entities

Suggested tables

- Offers
- Coupons
- CouponUsage
- ReferralProgram
- LoyaltyRewards
- Campaigns
- CustomerRewards

---

# API Endpoints

Example APIs

| Method | Endpoint | Purpose |
|----------|-----------|----------|
| GET | /api/v1/offers | List Offers |
| POST | /api/v1/offers | Create Offer |
| PUT | /api/v1/offers/{id} | Update Offer |
| DELETE | /api/v1/offers/{id} | Delete Offer |
| POST | /api/v1/coupons/validate | Validate Coupon |
| GET | /api/v1/coupons/history | Coupon Usage |

---

# Security Considerations

- Prevent coupon abuse.
- Validate customer eligibility.
- Prevent duplicate coupon redemption.
- Log all discount applications.
- Restrict offer management to authorized users.

---

# Best Practices

- Keep promotional campaigns time-bound.
- Track campaign effectiveness.
- Use clear eligibility rules.
- Limit high-value discounts.
- Notify customers before offers expire.
- Review inactive campaigns regularly.

---

# Future Enhancements

- AI-based personalized offers
- Membership plans
- Cashback rewards
- Gift cards
- Promotional banners
- QR code coupons
- Multi-coupon support
- Dynamic pricing engine

---

# Related Documents

- 33-pricing-model.md
- 34-subscription-model.md
- 10.9-settings-api.md
- 24.7-settings-screen.md
- 24.9-reports-dashboard.md

---

# Revision History

| Version | Date | Description |
|----------|------|-------------|
| 1.0 | July 2026 | Initial Offers & Discounts Documentation |
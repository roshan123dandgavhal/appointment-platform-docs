# Subscription Model

**Document ID:** BIZ-002  
**Project:** Appointment Platform (WhatsApp First SaaS)  
**Version:** 1.0  
**Status:** Draft

---

# Purpose

This document defines how subscriptions are created, managed, upgraded, renewed, suspended, and cancelled within the Appointment Platform.

The subscription system controls feature access, business limits, billing cycles, and account status.

---

# Objectives

- Manage customer subscriptions
- Support multiple subscription plans
- Automate renewals
- Control feature access
- Handle upgrades and downgrades
- Support free trials

---

# Scope

This document covers

- Free Trial
- Subscription Plans
- Subscription Lifecycle
- Renewals
- Upgrades
- Downgrades
- Suspension
- Cancellation
- Billing
- Feature Limits

---

# Subscription Overview

Each business has one active subscription.

The subscription determines

- Available features
- Booking limits
- Staff limits
- Customer limits
- Storage limits
- API access

---

# Subscription Lifecycle

```text
Business Registration

↓

Free Trial

↓

Choose Plan

↓

Payment

↓

Active Subscription

↓

Renewal

↓

Upgrade / Downgrade

↓

Cancel / Expire
```

---

# Subscription States

| Status | Description |
|----------|-------------|
| Trial | Free trial period |
| Active | Paid subscription |
| Pending Payment | Waiting for payment |
| Grace Period | Renewal overdue |
| Suspended | Access restricted |
| Expired | Subscription ended |
| Cancelled | User cancelled |

---

# Free Trial

Duration

- 14 Days

Features

- Full application access
- Limited bookings
- Limited WhatsApp conversations
- Single business account

At the end of the trial, the user must subscribe to continue using the platform.

---

# Subscription Plans

Supported Plans

- Starter
- Professional
- Business
- Enterprise

Plan details are defined in **33-pricing-model.md**.

---

# Subscription Workflow

```text
Trial

↓

Payment Success

↓

Subscription Activated

↓

Monthly Renewal

↓

Payment Success

↓

Continue

OR

Payment Failure

↓

Grace Period

↓

Suspension
```

---

# Subscription Activation

Subscription becomes active after

- Successful payment
- Payment verification
- Subscription record creation

---

# Renewal Process

Renewal frequency

- Monthly
- Yearly

Automatic renewal (recommended)

1. Payment initiated
2. Payment successful
3. Expiry date extended
4. Invoice generated
5. Confirmation notification sent

---

# Grace Period

If payment fails

Grace Period

- 7 Days

During grace period

- Existing data remains accessible
- New bookings may be restricted (optional)
- Reminder notifications sent

---

# Suspension

Account is suspended when

- Grace period expires
- Subscription payment remains unpaid
- Administrator suspends the account

Suspended users

- Cannot create bookings
- Cannot access premium features
- Data remains محفوظ (retained)

---

# Reactivation

Subscription is reactivated after

- Successful payment
- Administrator approval (if required)

User data is restored without loss.

---

# Upgrade Plan

Users may upgrade at any time.

Example

```text
Starter

↓

Professional

↓

Business

↓

Enterprise
```

Upgrade process

1. Select new plan
2. Calculate prorated amount
3. Complete payment
4. Activate new plan immediately

---

# Downgrade Plan

Downgrade becomes effective at the end of the current billing cycle.

Before downgrade

System verifies

- Booking limits
- Customer limits
- Staff limits
- Storage usage

---

# Cancellation

Users may cancel

- Immediately
- At end of billing cycle

After cancellation

- Subscription status = Cancelled
- Access continues until expiry date
- No further automatic renewals

---

# Feature Access

Features are enabled based on the active subscription.

Example

| Feature | Starter | Professional | Business | Enterprise |
|----------|----------|--------------|-----------|------------|
| Dashboard | ✓ | ✓ | ✓ | ✓ |
| Reports | Basic | Advanced | Advanced | Enterprise |
| API Access | ✗ | ✓ | ✓ | ✓ |
| Multi-Location | ✗ | ✗ | ✓ | ✓ |
| Custom Branding | ✗ | ✓ | ✓ | ✓ |

---

# Usage Limits

System validates

- Maximum staff
- Maximum customers
- Monthly bookings
- Storage
- WhatsApp usage

When a limit is reached

- Warning notification displayed
- Upgrade option shown

---

# Subscription Notifications

Automatically notify users

- Trial ending
- Payment success
- Payment failure
- Upcoming renewal
- Subscription expired
- Grace period ending
- Plan upgraded
- Plan downgraded

Notification channels

- Email
- WhatsApp
- In-App Notifications

---

# Billing Information

Store

- Billing address
- GST Number
- Company name
- Invoice history
- Payment history

---

# Invoice Generation

Generate invoices for

- New subscriptions
- Renewals
- Upgrades
- Add-ons

Invoice includes

- Invoice Number
- Plan Name
- Billing Period
- Tax Details
- Total Amount
- Payment Status

---

# Subscription Database Model

Suggested fields

| Field | Description |
|----------|-------------|
| Subscription ID | Unique identifier |
| Business ID | Linked business |
| Plan ID | Selected plan |
| Status | Current subscription status |
| Start Date | Subscription start |
| End Date | Subscription expiry |
| Renewal Date | Next billing date |
| Billing Cycle | Monthly / Yearly |
| Auto Renew | Enabled/Disabled |
| Payment Status | Paid / Pending / Failed |

---

# Admin Capabilities

Administrator can

- View subscriptions
- Change plan
- Extend subscription
- Suspend account
- Reactivate account
- Generate invoices
- View payment history

---

# Business Rules

- Only one active subscription per business.
- Expired subscriptions cannot access premium features.
- Trial converts to paid subscription after payment.
- Subscription changes are logged for auditing.
- Feature access is determined by the active plan.

---

# Future Enhancements

- Family or franchise subscriptions
- Coupon codes
- Referral discounts
- Usage-based billing
- Add-on marketplace
- Multiple payment gateways
- Auto invoice emailing
- AI-based upgrade recommendations

---

# Related Documents

- 33-pricing-model.md
- 10.9-settings-api.md
- 21-admin-web-application.md
- 24.7-settings-screen.md
- 29-production-readiness.md

---

# Revision History

| Version | Date | Description |
|----------|------|-------------|
| 1.0 | July 2026 | Initial Subscription Model Documentation |
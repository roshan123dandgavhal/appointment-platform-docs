# Pricing Model

**Document ID:** BIZ-001  
**Project:** Appointment Platform (WhatsApp First SaaS)  
**Version:** 1.0  
**Status:** Draft

---

# Purpose

This document defines the pricing strategy and subscription plans for the Appointment Platform.

The objective is to provide flexible pricing suitable for businesses of different sizes while generating recurring SaaS revenue.

---

# Objectives

- Affordable pricing for small businesses
- Scalable plans for growing businesses
- Predictable monthly recurring revenue (MRR)
- Easy plan upgrades
- Transparent pricing
- Feature-based subscription model

---

# Pricing Strategy

The platform follows a **Software as a Service (SaaS)** subscription model.

Customers subscribe to a monthly or yearly plan based on their business requirements.

---

# Target Customers

- Salons
- Clinics
- Doctors
- Gyms
- Spas
- Tutors
- Consultants
- Service Centers
- Beauty Parlors
- Small Businesses

---

# Subscription Plans

| Plan | Monthly | Yearly |
|-------|----------|---------|
| Starter | ₹499 | ₹4,999 |
| Professional | ₹999 | ₹9,999 |
| Business | ₹1,999 | ₹19,999 |
| Enterprise | Custom | Custom |

---

# Plan Comparison

| Feature | Starter | Professional | Business | Enterprise |
|----------|----------|--------------|-----------|------------|
| Businesses | 1 | 1 | Multiple | Unlimited |
| Staff | 5 | 20 | 100 | Unlimited |
| Customers | 1,000 | 10,000 | Unlimited | Unlimited |
| Bookings / Month | 500 | 5,000 | Unlimited | Unlimited |
| WhatsApp Integration | ✓ | ✓ | ✓ | ✓ |
| Dashboard | ✓ | ✓ | ✓ | ✓ |
| Reports | Basic | Advanced | Advanced | Enterprise |
| API Access | ✗ | ✓ | ✓ | ✓ |
| Custom Branding | ✗ | ✓ | ✓ | ✓ |
| Priority Support | ✗ | ✗ | ✓ | ✓ |
| Dedicated Account Manager | ✗ | ✗ | ✗ | ✓ |

---

# Free Trial

Duration

- 14 Days

Features

- Full access
- No credit card required
- Limited WhatsApp messages
- Limited bookings

---

# Billing Cycle

Supported billing

- Monthly
- Quarterly (Future)
- Yearly

Yearly plans receive approximately **2 months free** compared to monthly pricing.

---

# Payment Methods

Supported

- UPI
- Credit Card
- Debit Card
- Net Banking
- Wallets
- International Cards (Future)

Payment gateways (examples)

- Razorpay
- Stripe (Future)

---

# Usage Limits

## Starter

- 500 bookings/month
- 5 staff members
- 1 business
- 1,000 customers

---

## Professional

- 5,000 bookings/month
- 20 staff members
- Advanced reports
- API access

---

## Business

- Unlimited bookings
- Unlimited customers
- Multi-location support
- Priority support

---

## Enterprise

- Unlimited everything
- Dedicated infrastructure (optional)
- SLA support
- Custom integrations

---

# Add-On Pricing

| Add-On | Price |
|----------|--------|
| Additional Staff | ₹99/User/Month |
| Additional WhatsApp Number | ₹299/Month |
| Extra Storage (10 GB) | ₹199/Month |
| SMS Pack | As per usage |
| Premium Support | ₹999/Month |

---

# WhatsApp Charges

WhatsApp conversations are billed separately by Meta.

Platform options

- Customer uses their own WhatsApp Business account
- Platform may offer bundled plans (Future)

---

# Upgrade Flow

```text
Starter

↓

Professional

↓

Business

↓

Enterprise
```

Users can upgrade at any time.

---

# Downgrade Policy

Users may downgrade at the end of the current billing cycle.

If usage exceeds the downgraded plan limits, users must reduce usage before the downgrade takes effect.

---

# Cancellation Policy

Users can

- Cancel anytime
- Continue using the platform until the current billing period ends
- No automatic refunds for partial months

---

# Refund Policy

Suggested policy

- 7-day refund for annual plans (if applicable)
- No refund after the refund window
- Monthly plans are non-refundable once billed

---

# Discounts

Available for

- Annual subscriptions
- Educational institutions
- Non-profit organizations
- Promotional campaigns
- Referral programs

---

# Enterprise Pricing

Enterprise pricing depends on

- Number of businesses
- Number of users
- Custom integrations
- Dedicated infrastructure
- SLA requirements
- Support requirements

Pricing is provided through a custom quotation.

---

# Revenue Metrics

Track

- Monthly Recurring Revenue (MRR)
- Annual Recurring Revenue (ARR)
- Customer Lifetime Value (LTV)
- Customer Acquisition Cost (CAC)
- Churn Rate
- Average Revenue Per User (ARPU)

---

# Subscription Workflow

```text
User Registration

↓

Free Trial

↓

Choose Plan

↓

Payment

↓

Subscription Activated

↓

Monthly Renewal

↓

Upgrade / Downgrade

↓

Renew or Cancel
```

---

# Pricing Best Practices

- Keep pricing simple and transparent.
- Clearly communicate feature limits.
- Offer annual discounts to improve retention.
- Allow seamless plan upgrades.
- Monitor usage to recommend suitable plans.
- Notify users before reaching plan limits.

---

# Future Enhancements

- Usage-based billing
- Pay-as-you-go plans
- Coupon and promo codes
- Referral rewards
- Team-based licensing
- Marketplace integrations
- Automated invoicing
- GST-compliant billing

---

# Related Documents

- 21-admin-web-application.md
- 24.7-settings-screen.md
- 10.9-settings-api.md
- 29-production-readiness.md

---

# Revision History

| Version | Date | Description |
|----------|------|-------------|
| 1.0 | July 2026 | Initial Pricing Model Documentation |
# User Stories

**Document ID:** US-001  
**Project:** Appointment Platform  
**Version:** 1.0  
**Status:** Draft

---

# Purpose

This document defines the user stories for the Appointment Platform.

Each story describes a business requirement from the perspective of the end user. These stories will be used for planning, development, testing, and acceptance criteria.

---

# Actors

- Customer
- Business Admin
- Platform Admin
- Staff (Future)

---

# Customer User Stories

## US-001 - Start Booking

**As a** customer

**I want** to send "Hi" on WhatsApp

**So that** I can start booking an appointment.

### Acceptance Criteria

- Conversation starts automatically.
- No manual intervention required.
- Available services are displayed.

---

## US-002 - View Services

**As a** customer

**I want** to see all available services

**So that** I can choose the required service.

### Acceptance Criteria

- Only active services are displayed.
- Services are sorted alphabetically.
- Disabled services are hidden.

---

## US-003 - Select Service

**As a** customer

**I want** to select one service

**So that** I can continue booking.

### Acceptance Criteria

- Only one service can be selected.
- Invalid selections are rejected.

---

## US-004 - View Available Dates

**As a** customer

**I want** to view available dates

**So that** I can choose my preferred appointment day.

### Acceptance Criteria

- Only dates with available slots are displayed.
- Past dates are hidden.

---

## US-005 - Select Time Slot

**As a** customer

**I want** to choose an available slot

**So that** I can reserve that appointment.

### Acceptance Criteria

- Only available slots are shown.
- Fully booked slots are hidden.
- Expired slots cannot be selected.

---

## US-006 - Share My Name

**As a** customer

**I want** to provide my name when requested

**So that** the business can identify me.

### Acceptance Criteria

- Name is requested only when enabled in settings.
- Name is stored with customer profile.

---

## US-007 - Confirm Booking

**As a** customer

**I want** to confirm my booking

**So that** my appointment is reserved.

### Acceptance Criteria

- Booking summary is displayed.
- Confirmation creates a booking record.

---

## US-008 - Receive Confirmation

**As a** customer

**I want** to receive confirmation

**So that** I know my booking is successful.

### Acceptance Criteria

- Confirmation is sent immediately for auto-approved bookings.
- Pending message is shown when manual approval is required.

---

## US-009 - Cancel Booking

**As a** customer

**I want** to cancel my booking

**So that** another customer can use the slot.

### Acceptance Criteria

- Cancellation follows business rules.
- Slot becomes available again.

---

## US-010 - Receive Reminder (Future)

**As a** customer

**I want** to receive reminders

**So that** I don't miss my appointment.

---

# Business Admin User Stories

## US-011 - Login

**As a** business admin

**I want** to log in

**So that** I can manage my business.

---

## US-012 - Manage Services

**As a** business admin

**I want** to create, update, or disable services

**So that** customers can book available services.

---

## US-013 - Manage Service Categories

**As a** business admin

**I want** to organize services into categories

**So that** customers can easily browse services.

---

## US-014 - Manage Slots

**As a** business admin

**I want** to create appointment slots

**So that** customers can book available times.

---

## US-015 - Bulk Slot Creation

**As a** business admin

**I want** to create multiple slots at once

**So that** I save time.

---

## US-016 - Manage Bookings

**As a** business admin

**I want** to view bookings

**So that** I can manage appointments.

---

## US-017 - Approve Booking

**As a** business admin

**I want** to approve pending bookings

**So that** customers receive confirmation.

---

## US-018 - Reject Booking

**As a** business admin

**I want** to reject bookings

**So that** unavailable appointments are not confirmed.

---

## US-019 - Configure Business

**As a** business admin

**I want** to update business information

**So that** customers receive accurate information.

---

## US-020 - Configure Booking Rules

**As a** business admin

**I want** to configure booking settings

**So that** the booking process follows my business requirements.

Settings include:

- Auto Approval
- Ask Customer Name
- Cancellation Policy
- Booking Window
- Slot Capacity

---

## US-021 - Connect WhatsApp

**As a** business admin

**I want** to connect my WhatsApp Business Account

**So that** customers can book appointments.

---

## US-022 - Manage Customers

**As a** business admin

**I want** to view customer information

**So that** I can manage repeat customers.

---

## US-023 - Search Customers

**As a** business admin

**I want** to search customers

**So that** I can quickly find their bookings.

---

## US-024 - View Dashboard

**As a** business admin

**I want** to see booking statistics

**So that** I understand business performance.

---

# Platform Admin User Stories

## US-025 - Manage Businesses

**As a** platform admin

**I want** to create and manage businesses

**So that** multiple companies can use the platform.

---

## US-026 - Suspend Business

**As a** platform admin

**I want** to suspend businesses

**So that** policy violations can be handled.

---

## US-027 - Monitor Platform

**As a** platform admin

**I want** to monitor system health

**So that** the platform remains available.

---

# Future User Stories

## US-028 - Manage Staff

Assign appointments to staff members.

---

## US-029 - Manage Branches

Support multiple business locations.

---

## US-030 - Holiday Calendar

Define business holidays.

---

## US-031 - Working Hours

Configure weekly working hours.

---

## US-032 - Google Calendar Sync

Synchronize bookings with Google Calendar.

---

## US-033 - Payment Gateway

Collect payments before confirming appointments.

---

## US-034 - Offers & Coupons

Create promotional campaigns.

---

## US-035 - Loyalty Program

Reward repeat customers.

---

## US-036 - AI Assistant

Automatically answer customer questions.

---

## US-037 - Reports

Generate business reports.

---

## US-038 - Analytics Dashboard

View trends, bookings, revenue, and customer insights.

---

# Story Priority

| Priority | Description |
|----------|-------------|
| Must Have | Required for MVP |
| Should Have | High Priority |
| Could Have | Nice to Have |
| Future | Planned Later |

---

# MVP User Stories

- US-001 Start Booking
- US-002 View Services
- US-003 Select Service
- US-004 View Dates
- US-005 Select Slot
- US-006 Enter Name
- US-007 Confirm Booking
- US-008 Receive Confirmation
- US-011 Login
- US-012 Manage Services
- US-014 Manage Slots
- US-016 Manage Bookings
- US-017 Approve Booking
- US-019 Configure Business
- US-020 Configure Booking Rules
- US-021 Connect WhatsApp

---

# Future Releases

### Version 1.1

- Staff Management
- Holiday Calendar
- Working Hours
- Reminder Messages

### Version 1.2

- Multiple Branches
- Google Calendar
- Offers
- Coupons

### Version 2.0

- Payment Gateway
- AI Assistant
- Analytics
- Reports
- Public API

---

# Revision History

| Version | Date | Description |
|----------|------|-------------|
| 1.0 | July 2026 | Initial User Stories Document |
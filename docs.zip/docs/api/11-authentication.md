# Authentication

Purpose: Define authentication architecture using JWT.

Topics:
- JWT Authentication
- Login Flow
- Refresh Token
- Password Policy
- Session Management
- Security Best Practices

# Authorization

**Document ID:** API-012  
**Project:** Appointment Platform (WhatsApp First SaaS)  
**Version:** 1.0  
**Status:** Draft

---

# Purpose

This document defines the authorization model for the Appointment Platform.

Authentication verifies **who the user is**.

Authorization determines **what the user is allowed to do**.

This document applies only to authenticated system users such as Business Owners, Admins, Managers, Receptionists, and future Staff users.

WhatsApp customers do not require authentication or authorization.

---

# Objectives

- Secure every API
- Prevent unauthorized access
- Support multiple businesses (Multi-Tenant)
- Support Role-Based Access Control (RBAC)
- Allow future custom roles
- Audit all sensitive operations

---

# Authorization Architecture

```text
                +----------------------+
                |     React Admin      |
                +----------+-----------+
                           |
                     JWT Access Token
                           |
                           ▼
                +----------------------+
                |      Fastify API     |
                +----------+-----------+
                           |
                 JWT Authentication
                           |
                           ▼
                  Authorization Layer
                           |
          +----------------+----------------+
          |                                 |
    Validate Business              Validate Role
          |                                 |
          +----------------+----------------+
                           |
                     Execute Request
```

---

# Authorization Flow

```text
User Login
      │
      ▼
JWT Generated
      │
      ▼
Request API
      │
      ▼
Validate JWT
      │
      ▼
Find User
      │
      ▼
Check Business
      │
      ▼
Check Permission
      │
      ▼
Allow / Deny
```

---

# Multi-Tenant Authorization

The platform is designed for multiple businesses.

Each business can only access its own data.

Example

```text
Business A

Customers
Bookings
Services
Slots

Cannot access

Business B Data
```

---

# Authorization Levels

| Level | Description |
|---------|-------------|
| Platform | Internal Super Admin (Future) |
| Business | Business Owner |
| User | Admin / Manager / Receptionist |
| Customer | WhatsApp End User |

---

# User Roles

## OWNER

Highest permission inside a business.

Can

- Manage business
- Manage users
- Manage services
- Manage bookings
- Configure WhatsApp
- Update settings
- View reports

Cannot

- Access another business

---

## ADMIN

Business administrator.

Can

- Manage bookings
- Manage customers
- Manage slots
- Manage services
- View reports

Cannot

- Delete business
- Transfer ownership

---

## MANAGER

Can

- Approve bookings
- Reject bookings
- Create slots
- Manage schedules
- View reports

Cannot

- Manage users
- Configure billing
- Delete business

---

## RECEPTIONIST

Can

- View bookings
- Create bookings
- Cancel bookings
- View customers

Cannot

- Manage users
- Change settings
- Configure WhatsApp

---

## STAFF (Future)

Can

- View assigned appointments
- Update appointment status
- Mark appointment completed

---

# Permission Matrix

| Permission | Owner | Admin | Manager | Receptionist |
|------------|-------|-------|----------|---------------|
| View Dashboard | ✅ | ✅ | ✅ | ✅ |
| Manage Business | ✅ | ❌ | ❌ | ❌ |
| Manage Users | ✅ | ✅ | ❌ | ❌ |
| Manage Customers | ✅ | ✅ | ✅ | ✅ |
| Manage Services | ✅ | ✅ | ✅ | ❌ |
| Manage Slots | ✅ | ✅ | ✅ | ❌ |
| Manage Bookings | ✅ | ✅ | ✅ | ✅ |
| Approve Booking | ✅ | ✅ | ✅ | ❌ |
| Reject Booking | ✅ | ✅ | ✅ | ❌ |
| Business Settings | ✅ | ❌ | ❌ | ❌ |
| WhatsApp Settings | ✅ | ❌ | ❌ | ❌ |
| Reports | ✅ | ✅ | ✅ | View Only |

---

# Protected Resources

Every API endpoint must verify permissions.

Example

```text
GET /customers

Permission

customer.read
```

---

```text
POST /customers

Permission

customer.create
```

---

```text
PUT /customers/{id}

Permission

customer.update
```

---

```text
DELETE /customers/{id}

Permission

customer.delete
```

---

# Example Permission Names

```text
business.read

business.update

user.read

user.create

user.update

user.delete

customer.read

customer.create

customer.update

customer.delete

service.read

service.create

service.update

service.delete

slot.read

slot.create

slot.update

slot.delete

booking.read

booking.create

booking.approve

booking.reject

booking.cancel

report.read

settings.update
```

---

# API Authorization

Example

```http
GET /api/v1/bookings
```

Required Permission

```text
booking.read
```

---

```http
POST /api/v1/bookings
```

Required Permission

```text
booking.create
```

---

```http
POST /api/v1/bookings/{id}/approve
```

Required Permission

```text
booking.approve
```

---

# Authorization Middleware

Every protected request passes through middleware.

Responsibilities

- Validate JWT
- Validate Business
- Validate User Status
- Validate Permission
- Attach User Context

---

# Request Context

After authorization

```text
request.user.id

request.user.businessId

request.user.role

request.user.permissions
```

becomes available to controllers.

---

# Business Isolation

Every database query must include

```text
businessId
```

Example

Correct

```sql
SELECT *
FROM bookings
WHERE business_id = ?
```

Incorrect

```sql
SELECT *
FROM bookings
```

---

# Unauthorized Response

HTTP

```text
403 Forbidden
```

Example

```json
{
    "success": false,
    "message": "You do not have permission to perform this action."
}
```

---

# Authentication Failure

HTTP

```text
401 Unauthorized
```

Example

```json
{
    "success": false,
    "message": "Authentication required."
}
```

---

# Audit Logging

The following actions should be logged.

- Login
- Logout
- User Creation
- User Update
- Booking Approval
- Booking Rejection
- Settings Update
- Role Changes
- Permission Changes

---

# Future Enhancements

- Custom Roles
- Permission Groups
- Branch Level Permissions
- Department Level Permissions
- Staff Assignment Permissions
- API Key Authorization
- OAuth Integration
- Single Sign-On (SSO)

---

# Related Documents

- 10-api-design.md
- 10.1-auth-api.md
- 11-authentication.md
- 24-role-permission.md

---

# Revision History

| Version | Date | Description |
|----------|------|-------------|
| 1.0 | July 2026 | Initial Authorization Design |
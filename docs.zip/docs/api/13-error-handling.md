# Error Handling

**Document ID:** API-013  
**Project:** Appointment Platform (WhatsApp First SaaS)  
**Version:** 1.0  
**Status:** Draft

---

# Purpose

This document defines the standard error handling strategy for the Appointment Platform.

A consistent error response helps:

- Frontend developers
- Mobile applications
- WhatsApp Conversation Engine
- Third-party integrations
- Monitoring systems

All APIs must return errors using the standard response format.

---

# Objectives

- Consistent API responses
- Easy debugging
- Better user experience
- Secure error messages
- Proper logging
- Easier monitoring

---

# Error Categories

| Category | HTTP Status |
|----------|-------------|
| Validation Error | 400 |
| Authentication Error | 401 |
| Authorization Error | 403 |
| Resource Not Found | 404 |
| Conflict | 409 |
| Rate Limit | 429 |
| Internal Server Error | 500 |
| Service Unavailable | 503 |

---

# Standard Error Response

Every API should return the following structure.

```json
{
    "success": false,
    "error": {
        "code": "BOOKING_NOT_FOUND",
        "message": "Booking not found.",
        "details": []
    },
    "requestId": "f8c2e4d1",
    "timestamp": "2026-07-20T10:30:00Z"
}
```

---

# Response Fields

| Field | Description |
|---------|-------------|
| success | Always false |
| error.code | Application error code |
| error.message | Human-readable message |
| error.details | Validation details |
| requestId | Unique request identifier |
| timestamp | Response timestamp |

---

# Validation Error

HTTP Status

```text
400 Bad Request
```

Example

```json
{
    "success": false,
    "error": {
        "code": "VALIDATION_ERROR",
        "message": "Validation failed.",
        "details": [
            {
                "field": "mobileNumber",
                "message": "Mobile number is required."
            }
        ]
    }
}
```

---

# Authentication Error

HTTP Status

```text
401 Unauthorized
```

Example

```json
{
    "success": false,
    "error": {
        "code": "UNAUTHORIZED",
        "message": "Authentication required."
    }
}
```

---

# Authorization Error

HTTP Status

```text
403 Forbidden
```

Example

```json
{
    "success": false,
    "error": {
        "code": "FORBIDDEN",
        "message": "You do not have permission to perform this action."
    }
}
```

---

# Resource Not Found

HTTP Status

```text
404 Not Found
```

Example

```json
{
    "success": false,
    "error": {
        "code": "CUSTOMER_NOT_FOUND",
        "message": "Customer not found."
    }
}
```

---

# Conflict Error

HTTP Status

```text
409 Conflict
```

Example

```json
{
    "success": false,
    "error": {
        "code": "SLOT_ALREADY_BOOKED",
        "message": "Selected slot is no longer available."
    }
}
```

---

# Rate Limit Error

HTTP Status

```text
429 Too Many Requests
```

Example

```json
{
    "success": false,
    "error": {
        "code": "RATE_LIMIT_EXCEEDED",
        "message": "Too many requests. Please try again later."
    }
}
```

---

# Internal Server Error

HTTP Status

```text
500 Internal Server Error
```

Example

```json
{
    "success": false,
    "error": {
        "code": "INTERNAL_SERVER_ERROR",
        "message": "An unexpected error occurred."
    }
}
```

---

# Service Unavailable

HTTP Status

```text
503 Service Unavailable
```

Example

```json
{
    "success": false,
    "error": {
        "code": "SERVICE_UNAVAILABLE",
        "message": "Service is temporarily unavailable."
    }
}
```

---

# Common Application Error Codes

| Error Code | Description |
|------------|-------------|
| VALIDATION_ERROR | Invalid request |
| INVALID_CREDENTIALS | Login failed |
| UNAUTHORIZED | Authentication required |
| FORBIDDEN | Permission denied |
| CUSTOMER_NOT_FOUND | Customer does not exist |
| SERVICE_NOT_FOUND | Service does not exist |
| SLOT_NOT_FOUND | Slot does not exist |
| SLOT_ALREADY_BOOKED | Slot already booked |
| BOOKING_NOT_FOUND | Booking not found |
| BOOKING_ALREADY_APPROVED | Booking already approved |
| BOOKING_ALREADY_CANCELLED | Booking already cancelled |
| DUPLICATE_CUSTOMER | Customer already exists |
| BUSINESS_NOT_FOUND | Business not found |
| USER_NOT_FOUND | User not found |
| WHATSAPP_CONFIGURATION_MISSING | WhatsApp not configured |
| DATABASE_ERROR | Database operation failed |
| INTERNAL_SERVER_ERROR | Unexpected server error |

---

# Validation Rules

Validation errors should include the affected field.

Example

```json
{
    "field": "appointmentDate",
    "message": "Appointment date cannot be in the past."
}
```

Multiple validation errors should be returned together whenever possible.

---

# Logging Strategy

The following errors must be logged.

- Database exceptions
- External API failures
- Authentication failures
- Authorization failures
- Webhook failures
- Payment failures (Future)
- Unexpected exceptions

Sensitive information must never be written to logs.

---

# Error Handling Flow

```text
Incoming Request
        │
        ▼
Input Validation
        │
        ▼
Business Validation
        │
        ▼
Controller
        │
        ▼
Service Layer
        │
        ▼
Database / External API
        │
        ▼
Exception
        │
        ▼
Global Error Handler
        │
        ▼
Standard Error Response
```

---

# WhatsApp Error Handling

If an incoming WhatsApp message cannot be processed:

- Log the error
- Save the raw webhook payload
- Return HTTP 200 to Meta (to prevent repeated retries)
- Notify administrators if the error is critical

---

# Database Errors

Do not expose raw database errors.

Incorrect

```text
Duplicate entry '9876543210' for key 'customers.mobile_number'
```

Correct

```json
{
    "success": false,
    "error": {
        "code": "DUPLICATE_CUSTOMER",
        "message": "Customer already exists."
    }
}
```

---

# Security Guidelines

Never expose:

- Stack traces
- SQL queries
- Passwords
- JWT tokens
- Internal server paths
- Environment variables

---

# Monitoring

Critical errors should be reported to the monitoring system.

Examples

- Database connection failure
- WhatsApp API unavailable
- AWS service failure
- High error rate
- Unhandled exception

---

# Future Enhancements

- Error Localization (Multi-language)
- Automatic Retry Mechanism
- Distributed Tracing
- Dead Letter Queue (DLQ)
- AI-Based Error Analysis
- Centralized Error Dashboard

---

# Related Documents

- 10-api-design.md
- 11-authentication.md
- 12-authorization.md
- 15-webhook-api.md
- 20-whatsapp-webhook-processing.md
- 29.3-monitoring.md

---

# Revision History

| Version | Date | Description |
|----------|------|-------------|
| 1.0 | July 2026 | Initial Error Handling Design |
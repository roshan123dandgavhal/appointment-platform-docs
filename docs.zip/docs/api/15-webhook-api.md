# Webhook API

**Document ID:** API-015  
**Project:** Appointment Platform (WhatsApp First SaaS)  
**Version:** 1.0  
**Status:** Draft

---

# Purpose

This document defines the Webhook API architecture used by the Appointment Platform.

The primary webhook integration is with the **Meta WhatsApp Cloud API**.

The platform receives incoming WhatsApp messages through webhooks, processes them, and sends appropriate responses to customers.

---

# Objectives

- Receive incoming WhatsApp messages
- Verify webhook authenticity
- Process events asynchronously
- Ensure idempotent processing
- Support future third-party webhooks
- Maintain high reliability

---

# Scope

Current

- Meta WhatsApp Cloud API

Future

- Payment Gateway
- Google Calendar
- Outlook Calendar
- CRM Integration
- Email Providers
- SMS Providers

---

# Webhook Architecture

```text
Customer
    │
    ▼
WhatsApp
    │
    ▼
Meta Cloud API
    │
    ▼
Webhook Endpoint
    │
    ▼
Webhook Validation
    │
    ▼
Message Queue
    │
    ▼
Conversation Engine
    │
    ▼
Business Logic
    │
    ▼
Database
    │
    ▼
Reply to Customer
```

---

# Webhook Endpoints

## Verify Webhook

```http
GET /api/v1/webhooks/whatsapp
```

Purpose

Verify webhook ownership during Meta configuration.

---

## Receive Events

```http
POST /api/v1/webhooks/whatsapp
```

Purpose

Receive incoming WhatsApp events.

---

# Webhook Verification

During webhook setup Meta sends:

```http
hub.mode

hub.verify_token

hub.challenge
```

Example Request

```text
GET /webhooks/whatsapp

hub.mode=subscribe

hub.verify_token=appointment-platform

hub.challenge=123456789
```

---

# Verification Response

```text
123456789
```

If verification succeeds

HTTP Status

```text
200 OK
```

Otherwise

```text
403 Forbidden
```

---

# Incoming Webhook

Example

```http
POST /api/v1/webhooks/whatsapp
```

---

# Request Body

Meta sends a JSON payload containing

- Message
- Contact
- Timestamp
- Event Type

Example

```json
{
  "object": "whatsapp_business_account",
  "entry": [
    {
      "changes": [
        {
          "field": "messages"
        }
      ]
    }
  ]
}
```

---

# Supported Events

| Event | Description |
|---------|-------------|
| Message Received | Customer sends message |
| Interactive Reply | Customer selects button |
| List Reply | Customer selects list item |
| Message Delivered | Outgoing message delivered |
| Message Read | Customer read message |
| Message Failed | Delivery failed |

---

# Webhook Processing Flow

```text
Receive Request
      │
      ▼
Validate Signature
      │
      ▼
Validate JSON
      │
      ▼
Store Raw Payload
      │
      ▼
Push To Queue
      │
      ▼
Return HTTP 200
      │
      ▼
Background Processing
```

---

# Why Queue Processing?

The webhook should respond quickly.

Heavy processing should happen asynchronously.

Benefits

- Faster response
- Better reliability
- Retry support
- Higher scalability

---

# Idempotency

The same webhook may be delivered multiple times.

The system must process each message only once.

Unique Identifier

```text
messageId
```

Before processing

Check

```text
Has this message already been processed?
```

If Yes

Ignore.

---

# Database Table

Suggested Table

```text
webhook_events
```

Fields

- id
- businessId
- provider
- eventType
- messageId
- payload
- status
- receivedAt
- processedAt

---

# HTTP Responses

Successful Processing

```text
200 OK
```

Invalid Request

```text
400 Bad Request
```

Unauthorized

```text
401 Unauthorized
```

Forbidden

```text
403 Forbidden
```

Server Error

```text
500 Internal Server Error
```

---

# Retry Strategy

Meta may retry webhook delivery if no successful response is received.

The application should

- Return 200 immediately after validation
- Process in the background
- Avoid duplicate processing

---

# Error Handling

If processing fails

- Save payload
- Log exception
- Mark event as failed
- Retry processing

Never lose incoming webhook data.

---

# Security

Webhook endpoint must

- Use HTTPS
- Validate Meta signature
- Verify webhook token
- Reject malformed payloads
- Log suspicious requests

---

# Rate Limiting

Protect against abuse.

Recommended

- IP Rate Limiting
- Request Size Limits
- Maximum Concurrent Requests

---

# Logging

Log

- Request ID
- Event Type
- Business ID
- Message ID
- Processing Time
- Processing Status

Do not log sensitive customer information unless required for debugging.

---

# Monitoring

Monitor

- Webhook Response Time
- Failed Events
- Queue Length
- Processing Time
- Retry Count
- Error Rate

---

# Future Providers

The webhook framework should support additional providers.

Examples

- Razorpay
- Stripe
- Google Calendar
- Microsoft Outlook
- Twilio SMS
- SendGrid

Each provider should have its own webhook handler while sharing common validation, logging, and retry mechanisms.

---

# Business Rules

- Every webhook event must be stored before processing.
- Every event must have a unique identifier.
- Duplicate events must not be processed.
- Webhook endpoints must always use HTTPS.
- Processing should be asynchronous.
- Failed events should be available for manual retry.

---

# Related Documents

- 10-api-design.md
- 10.7-whatsapp-api.md
- 11-authentication.md
- 12-authorization.md
- 13-error-handling.md
- 14-api-versioning.md
- 16-whatsapp-architecture.md
- 20-whatsapp-webhook-processing.md

---

# Revision History

| Version | Date | Description |
|----------|------|-------------|
| 1.0 | July 2026 | Initial Webhook API Design |
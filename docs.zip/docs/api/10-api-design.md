# API Design

**Document ID:** API-001  
**Project:** Appointment Platform  
**Version:** 1.0  
**Status:** Draft

---

# Purpose

This document defines the REST API design for the Appointment Platform.

The APIs will be consumed by:

- React Admin Portal
- WhatsApp Webhook
- Future Mobile App
- Third-party Integrations

---

# Technology

| Item | Value |
|------|-------|
| Framework | Fastify |
| Language | TypeScript |
| ORM | Prisma |
| Database | PostgreSQL |
| Authentication | JWT |
| API Style | REST |

---

# API Design Principles

- RESTful APIs
- JSON Request/Response
- Stateless APIs
- JWT Authentication
- Multi-Tenant
- Versioned APIs
- Standard Error Responses

---

# Base URL

```text
/api/v1
```

Example

```text
/api/v1/services
/api/v1/bookings
/api/v1/customers
```

---

# API Modules

| Module | Description |
|---------|-------------|
| Authentication | Login & Token Management |
| Business | Business Profile |
| Users | System Users |
| Customers | WhatsApp Customers |
| Services | Service Management |
| Categories | Service Categories |
| Slots | Appointment Slots |
| Bookings | Appointment Booking |
| WhatsApp | Webhooks |
| Notifications | Message History |
| Dashboard | Statistics |
| Settings | Business Configuration |

---

# Standard Request Headers

```http
Authorization: Bearer <JWT_TOKEN>

Content-Type: application/json

Accept: application/json
```

---

# Standard Success Response

```json
{
  "success": true,
  "message": "Operation completed successfully.",
  "data": {}
}
```

---

# Standard Error Response

```json
{
  "success": false,
  "message": "Validation failed.",
  "errors": [
    {
      "field": "serviceId",
      "message": "Service is required."
    }
  ]
}
```

---

# Authentication APIs

## Login

```http
POST /api/v1/auth/login
```

Request

```json
{
  "email": "admin@example.com",
  "password": "password"
}
```

Response

```json
{
  "token": "jwt-token",
  "user": {}
}
```

---

## Logout

```http
POST /api/v1/auth/logout
```

---

## Refresh Token

```http
POST /api/v1/auth/refresh
```

---

# Business APIs

## Get Business

```http
GET /api/v1/business
```

---

## Update Business

```http
PUT /api/v1/business
```

---

# Customer APIs

## Get Customers

```http
GET /api/v1/customers
```

Supports

- Pagination
- Search
- Sorting

---

## Get Customer

```http
GET /api/v1/customers/{id}
```

---

## Create Customer

```http
POST /api/v1/customers
```

---

## Update Customer

```http
PUT /api/v1/customers/{id}
```

---

## Delete Customer

```http
DELETE /api/v1/customers/{id}
```

Soft Delete Only

---

# Service Category APIs

## List Categories

```http
GET /api/v1/service-categories
```

---

## Create Category

```http
POST /api/v1/service-categories
```

---

## Update Category

```http
PUT /api/v1/service-categories/{id}
```

---

## Delete Category

```http
DELETE /api/v1/service-categories/{id}
```

---

# Service APIs

## List Services

```http
GET /api/v1/services
```

---

## Get Service

```http
GET /api/v1/services/{id}
```

---

## Create Service

```http
POST /api/v1/services
```

Example Request

```json
{
  "categoryId":"uuid",
  "name":"Hair Cut",
  "duration":30,
  "price":200
}
```

---

## Update Service

```http
PUT /api/v1/services/{id}
```

---

## Delete Service

```http
DELETE /api/v1/services/{id}
```

---

# Slot APIs

## Get Slots

```http
GET /api/v1/slots
```

Filters

- Date
- Service
- Status

---

## Create Slot

```http
POST /api/v1/slots
```

---

## Bulk Create Slots

```http
POST /api/v1/slots/bulk
```

---

## Update Slot

```http
PUT /api/v1/slots/{id}
```

---

## Delete Slot

```http
DELETE /api/v1/slots/{id}
```

---

# Booking APIs

## Get Bookings

```http
GET /api/v1/bookings
```

Filters

- Date
- Customer
- Status
- Service

---

## Get Booking

```http
GET /api/v1/bookings/{id}
```

---

## Create Booking

```http
POST /api/v1/bookings
```

---

## Approve Booking

```http
POST /api/v1/bookings/{id}/approve
```

---

## Reject Booking

```http
POST /api/v1/bookings/{id}/reject
```

---

## Cancel Booking

```http
POST /api/v1/bookings/{id}/cancel
```

---

# Notification APIs

## List Notifications

```http
GET /api/v1/notifications
```

---

## Retry Notification

```http
POST /api/v1/notifications/{id}/retry
```

---

# Dashboard APIs

## Dashboard Summary

```http
GET /api/v1/dashboard
```

Returns

- Today's Bookings
- Pending Bookings
- Total Customers
- Total Services

---

# Settings APIs

## Get Settings

```http
GET /api/v1/settings
```

---

## Update Settings

```http
PUT /api/v1/settings
```

---

# WhatsApp APIs

## Verify Webhook

```http
GET /api/v1/webhooks/whatsapp
```

---

## Receive Messages

```http
POST /api/v1/webhooks/whatsapp
```

---

## Send Message

```http
POST /api/v1/whatsapp/send
```

---

# HTTP Status Codes

| Code | Description |
|------|-------------|
| 200 | Success |
| 201 | Created |
| 204 | No Content |
| 400 | Bad Request |
| 401 | Unauthorized |
| 403 | Forbidden |
| 404 | Not Found |
| 409 | Conflict |
| 422 | Validation Error |
| 500 | Internal Server Error |

---

# Pagination Standard

Request

```http
GET /api/v1/customers?page=1&limit=20
```

Response

```json
{
  "data": [],
  "pagination": {
    "page": 1,
    "limit": 20,
    "total": 150,
    "totalPages": 8
  }
}
```

---

# Filtering

Example

```http
GET /api/v1/bookings?status=CONFIRMED
```

---

# Sorting

```http
GET /api/v1/bookings?sort=createdAt&order=desc
```

---

# Search

```http
GET /api/v1/customers?search=John
```

---

# API Security

- JWT Authentication
- HTTPS Only
- Input Validation
- SQL Injection Protection
- Rate Limiting
- Audit Logging

---

# Future APIs

Version 1.1

- Staff APIs
- Holiday APIs
- Working Hours APIs

Version 1.2

- Branch APIs
- Google Calendar APIs
- Reminder APIs

Version 2.0

- Payment APIs
- Subscription APIs
- Reports APIs
- Analytics APIs
- AI APIs
- Public Integration APIs

---

# API Versioning

Current Version

```text
v1
```

Future

```text
v2
```

Old versions will remain supported for backward compatibility.

---

# Revision History

| Version | Date | Description |
|----------|------|-------------|
| 1.0 | July 2026 | Initial API Design Document |
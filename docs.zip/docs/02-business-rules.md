# Business Rules

**Project:** Appointment Platform  
**Document Version:** 1.0  
**Status:** Draft

---

# 1. Purpose

This document defines the business rules governing the Appointment Platform.

Business rules describe **how the platform must behave**, regardless of implementation technology. These rules serve as the foundation for database design, APIs, validation, testing, and user experience.

---

# 2. Multi-Tenant Rules

### BR-001

The platform shall support multiple businesses (tenants).

---

### BR-002

Each business is completely isolated from every other business.

---

### BR-003

Users belonging to one business shall never access another business's data.

---

### BR-004

Every business shall have its own configuration and settings.

---

### BR-005

Every business shall connect its own WhatsApp Business Account.

---

# 3. Business Rules

### BR-006

A business must be active before customers can book appointments.

---

### BR-007

Inactive businesses cannot receive new bookings.

---

### BR-008

A business may temporarily disable online booking.

---

### BR-009

A business may define its own timezone.

---

### BR-010

Every business shall have configurable booking preferences.

---

# 4. User Rules

### BR-011

Every business shall have at least one Business Administrator.

---

### BR-012

Business Administrators can manage only their own business.

---

### BR-013

Staff users are optional.

---

### BR-014

Customer login is not required for booking appointments.

---

# 5. Customer Rules

### BR-015

Customers are identified primarily by their WhatsApp mobile number.

---

### BR-016

The platform shall optionally request the customer's name.

---

### BR-017

Whether customer name is mandatory shall be configurable.

---

### BR-018

Returning customers shall be recognized using their mobile number.

---

### BR-019

Customer booking history shall be preserved.

---

# 6. Service Rules

### BR-020

Every service belongs to exactly one business.

---

### BR-021

A service cannot exist without a business.

---

### BR-022

A business may create unlimited services.

---

### BR-023

Inactive services cannot be booked.

---

### BR-024

Each service shall define an appointment duration.

---

### BR-025

Service pricing is optional in MVP.

---

### BR-026

Service categories are optional.

---

# 7. Slot Rules

### BR-027

Slots belong to a business.

---

### BR-028

Slots may optionally belong to a service.

---

### BR-029

Businesses may create one-time or recurring slots.

---

### BR-030

Slots cannot overlap when overlap prevention is enabled.

---

### BR-031

Expired slots cannot be booked.

---

### BR-032

Fully booked slots become unavailable.

---

### BR-033

Cancelled bookings release the slot.

---

# 8. Booking Rules

### BR-034

Bookings require a valid service.

---

### BR-035

Bookings require a valid date.

---

### BR-036

Bookings require an available slot.

---

### BR-037

Double booking is not allowed.

---

### BR-038

Bookings may require approval.

---

### BR-039

If Auto Approval is enabled, bookings are confirmed immediately.

---

### BR-040

If Manual Approval is enabled, bookings remain Pending until approved.

---

### BR-041

Rejected bookings cannot become Confirmed.

---

### BR-042

Customers may cancel appointments according to business policy.

---

### BR-043

Businesses may cancel appointments.

---

# 9. WhatsApp Rules

### BR-044

Customer communication occurs primarily through WhatsApp.

---

### BR-045

Incoming WhatsApp messages determine the target business using the receiving phone number.

---

### BR-046

Each business shall use its own WhatsApp Business Account.

---

### BR-047

Conversation state shall be maintained during the booking flow.

---

### BR-048

The platform shall recover gracefully if the conversation expires.

---

# 10. Approval Rules

### BR-049

Approval mode shall be configurable.

---

### BR-050

Approvers shall receive booking notifications.

---

### BR-051

Customers shall receive approval notifications.

---

### BR-052

Customers shall receive rejection notifications.

---

# 11. Notification Rules

### BR-053

Booking confirmation shall generate a WhatsApp message.

---

### BR-054

Booking cancellation shall generate a WhatsApp message.

---

### BR-055

Reminder notifications are planned for a future release.

---

# 12. Security Rules

### BR-056

Users shall authenticate before accessing the web portal.

---

### BR-057

Passwords shall never be stored in plain text.

---

### BR-058

Every API request shall verify business ownership.

---

### BR-059

Administrative operations shall require authentication.

---

# 13. Audit Rules

### BR-060

Important business operations shall be auditable.

Examples:

- Service Created
- Slot Updated
- Booking Approved
- Booking Cancelled
- Settings Changed

---

# 14. Future Business Rules

The following capabilities are planned for future releases.

## Working Hours

Businesses define weekly schedules.

---

## Holiday Calendar

Businesses configure holidays.

---

## Multiple Branches

Businesses manage multiple physical locations.

---

## Staff Assignment

Appointments may be assigned to individual staff members.

---

## Waiting List

Customers join a waiting list when no slots are available.

---

## Google Calendar

Bookings synchronize with Google Calendar.

---

## Payment Gateway

Businesses optionally require payment before confirmation.

---

## AI Assistant

AI assists customers during booking.

---

## Offers

Businesses create promotional campaigns.

---

## Loyalty Program

Reward repeat customers.

---

## Reports & Analytics

Generate business insights and operational reports.

---

# 15. Guiding Principles

The platform shall always follow these principles:

1. Configuration over hardcoding.
2. Multi-tenant by design.
3. WhatsApp-first customer experience.
4. Secure by default.
5. API-first architecture.
6. Extensible without code changes.
7. Backward compatibility where possible.
8. Simplicity for business owners.
9. Consistent user experience.
10. Scalable architecture.

---

# 16. Rule Change Process

Business rules evolve over time.

Any new feature should:

1. Introduce new business rules if required.
2. Update existing rules when behavior changes.
3. Preserve backward compatibility whenever possible.
4. Be reviewed before implementation.

---

# Revision History

| Version | Date | Description |
|----------|------|-------------|
| 1.0 | July 2026 | Initial version |
# Message Templates

**Document ID:** WA-004  
**Project:** Appointment Platform (WhatsApp First SaaS)  
**Version:** 1.0  
**Status:** Draft

---

# Purpose

This document defines all WhatsApp message templates used by the Appointment Platform.

The platform should use consistent, professional, and user-friendly messages throughout the customer journey.

---

# Objectives

- Standardize customer communication
- Improve customer experience
- Support reusable templates
- Support future localization
- Reduce duplicate message creation

---

# Template Categories

| Category | Description |
|-----------|-------------|
| Welcome | Greeting new customers |
| Service Selection | Choose a service |
| Date Selection | Select appointment date |
| Slot Selection | Select available slot |
| Booking Confirmation | Confirm appointment |
| Pending Approval | Waiting for approval |
| Booking Approved | Appointment confirmed |
| Booking Rejected | Booking rejected |
| Booking Cancelled | Appointment cancelled |
| Reminder | Upcoming appointment |
| Help | Help menu |
| Error | Invalid input |
| Session Expired | Conversation expired |

---

# Welcome Message

**Trigger**

Customer sends:

```text
Hi
Hello
Hey
```

**Message**

```text
👋 Welcome to {{businessName}}

We're happy to assist you.

Please choose an option.

1️⃣ Book Appointment
2️⃣ View My Booking
3️⃣ Help
```

---

# Service Selection

**Trigger**

Customer chooses "Book Appointment"

**Message**

```text
Please select a service.

1️⃣ Haircut
2️⃣ Facial
3️⃣ Beard Trim

Reply with the option number.
```

> Service names are dynamic and come from the database.

---

# Date Selection

**Trigger**

Service selected.

**Message**

```text
Please choose your preferred date.

1️⃣ Today
2️⃣ Tomorrow
3️⃣ Select Another Date
```

---

# Slot Selection

**Trigger**

Date selected.

**Message**

```text
Available Slots

1️⃣ 10:00 AM
2️⃣ 10:30 AM
3️⃣ 11:00 AM
4️⃣ 11:30 AM

Reply with your preferred slot.
```

---

# Booking Summary

**Trigger**

Slot selected.

**Message**

```text
Please review your appointment.

Service : {{serviceName}}

Date : {{appointmentDate}}

Time : {{slotTime}}

Reply

YES - Confirm

NO - Cancel
```

---

# Booking Confirmed (Auto Approval)

**Trigger**

Auto Approval enabled.

**Message**

```text
✅ Appointment Confirmed

Booking ID

{{bookingNumber}}

Service

{{serviceName}}

Date

{{appointmentDate}}

Time

{{slotTime}}

Thank you for choosing us.
```

---

# Booking Pending Approval

**Trigger**

Manual approval enabled.

**Message**

```text
✅ Booking Request Received

Your appointment request has been submitted.

Our team will review it shortly.

You'll receive a confirmation once approved.
```

---

# Booking Approved

**Trigger**

Business approves booking.

**Message**

```text
🎉 Great News!

Your appointment has been approved.

Booking ID

{{bookingNumber}}

Date

{{appointmentDate}}

Time

{{slotTime}}

See you soon.
```

---

# Booking Rejected

**Trigger**

Business rejects booking.

**Message**

```text
We're sorry.

Unfortunately your requested appointment could not be approved.

Please book another available slot.
```

---

# Booking Cancelled

**Trigger**

Customer cancels booking.

**Message**

```text
Your appointment has been cancelled successfully.

We hope to serve you again.

Reply HI anytime to book another appointment.
```

---

# Reminder (24 Hours Before)

```text
⏰ Appointment Reminder

This is a reminder for your upcoming appointment.

Service

{{serviceName}}

Date

{{appointmentDate}}

Time

{{slotTime}}

See you soon.
```

---

# Reminder (2 Hours Before)

```text
Reminder

Your appointment starts in approximately 2 hours.

We look forward to seeing you.
```

---

# Appointment Completed

```text
Thank you for visiting us.

We hope you had a great experience.

Reply HI whenever you'd like to book another appointment.
```

---

# Help Message

```text
Available Commands

1️⃣ Book Appointment

2️⃣ View Booking

3️⃣ Cancel Booking

4️⃣ Contact Support
```

---

# Invalid Input

```text
Sorry, I didn't understand that.

Please choose one of the available options.
```

---

# No Available Slots

```text
Sorry.

No slots are available for the selected date.

Please choose another date.
```

---

# Service Not Available

```text
The selected service is currently unavailable.

Please choose another service.
```

---

# Booking Not Found

```text
We couldn't find any active booking for your mobile number.
```

---

# Session Expired

```text
Your previous session has expired.

Please type HI to start a new booking.
```

---

# Business Closed

```text
Sorry.

The business is currently closed.

Please try again during business hours.
```

---

# Holiday Message

```text
The selected date is a holiday.

Please choose another available date.
```

---

# Internal Error

```text
Sorry.

Something went wrong while processing your request.

Please try again in a few minutes.
```

---

# Notification to Business User

```text
New Booking Request

Customer

{{customerName}}

Service

{{serviceName}}

Date

{{appointmentDate}}

Please review the request.
```

---

# Booking Approved Notification

```text
Booking Approved Successfully.

The customer has been notified automatically.
```

---

# Booking Rejected Notification

```text
Booking Rejected Successfully.

The customer has been informed.
```

---

# Dynamic Variables

| Variable | Description |
|-----------|-------------|
| {{businessName}} | Business name |
| {{customerName}} | Customer name |
| {{serviceName}} | Selected service |
| {{appointmentDate}} | Appointment date |
| {{slotTime}} | Appointment time |
| {{bookingNumber}} | Booking reference |
| {{branchName}} | Branch name (Future) |
| {{staffName}} | Assigned staff (Future) |

---

# Template Management

All templates should be stored in the database.

Each business can customize:

- Welcome message
- Reminder message
- Cancellation message
- Approval message
- Rejection message

System templates should have default values.

---

# Future Enhancements

- Multi-language templates
- Rich media templates
- Image messages
- PDF attachments
- Voice messages
- Promotional campaigns
- Festival greetings
- Feedback request templates

---

# Related Documents

- 16-whatsapp-architecture.md
- 17-conversation-engine.md
- 18-conversation-state-machine.md
- 20-whatsapp-webhook-processing.md
- 20.8-template-management.md

---

# Revision History

| Version | Date | Description |
|----------|------|-------------|
| 1.0 | July 2026 | Initial Message Templates Design |
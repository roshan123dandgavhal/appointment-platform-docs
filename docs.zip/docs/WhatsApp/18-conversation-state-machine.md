# Conversation State Machine

**Document ID:** WA-003  
**Project:** Appointment Platform (WhatsApp First SaaS)  
**Version:** 1.0  
**Status:** Draft

---

# Purpose

The Conversation State Machine defines how a customer moves through the appointment booking journey on WhatsApp.

Every incoming message is processed based on the customer's current conversation state.

This ensures the conversation remains predictable, scalable, and easy to maintain.

---

# Objectives

- Standardize conversation flow
- Prevent invalid transitions
- Resume interrupted conversations
- Support multiple business types
- Keep customer experience simple

---

# What is a State?

A state represents the current step of the customer's conversation.

Example

```text
Customer says "Hi"

Current State

START

↓

System replies

Choose a Service

Current State

SERVICE_SELECTION
```

---

# State Machine Overview

```text
START
   │
   ▼
GREETING
   │
   ▼
SERVICE_SELECTION
   │
   ▼
DATE_SELECTION
   │
   ▼
SLOT_SELECTION
   │
   ▼
BOOKING_CONFIRMATION
   │
   ▼
AUTO_APPROVAL ?
   │
   ├──────────────► BOOKING_CONFIRMED
   │
   ▼
PENDING_APPROVAL
   │
   ▼
BOOKING_CONFIRMED
   │
   ▼
REMINDER_SENT
   │
   ▼
COMPLETED
```

---

# Conversation States

| State | Description |
|---------|-------------|
| START | New customer |
| GREETING | Welcome message |
| SERVICE_SELECTION | Customer selects service |
| DATE_SELECTION | Customer selects appointment date |
| SLOT_SELECTION | Customer selects available slot |
| BOOKING_CONFIRMATION | Customer confirms booking |
| PENDING_APPROVAL | Waiting for business approval |
| BOOKING_CONFIRMED | Booking confirmed |
| BOOKING_CANCELLED | Booking cancelled |
| REMINDER_SENT | Reminder delivered |
| COMPLETED | Appointment completed |
| SESSION_EXPIRED | Conversation expired |

---

# State Details

---

## START

Purpose

Beginning of a conversation.

Expected Input

```text
Hi
Hello
Hey
Book Appointment
```

Next State

```text
GREETING
```

---

## GREETING

System Response

```text
Welcome to ABC Business 👋

Please choose a service.
```

Next State

```text
SERVICE_SELECTION
```

---

## SERVICE_SELECTION

Customer selects one available service.

Example

```text
1. Haircut

2. Facial

3. Beard Trim
```

System validates

- Service exists
- Service is active

Next State

```text
DATE_SELECTION
```

---

## DATE_SELECTION

Customer selects appointment date.

Example

```text
Today

Tomorrow

25 July

26 July
```

Validation

- Date is valid
- Date is not in the past
- Business is open

Next State

```text
SLOT_SELECTION
```

---

## SLOT_SELECTION

Customer selects an available slot.

Example

```text
10:00 AM

10:30 AM

11:00 AM
```

Validation

- Slot exists
- Slot available
- Capacity available

Next State

```text
BOOKING_CONFIRMATION
```

---

## BOOKING_CONFIRMATION

System displays booking summary.

Example

```text
Service

Haircut

Date

25 July

Time

10:30 AM

Reply YES to confirm.
```

Customer Options

```text
YES

NO
```

---

If YES

Check business settings.

---

## Auto Approval

If Auto Approval is enabled

Next State

```text
BOOKING_CONFIRMED
```

---

## Manual Approval

If Manual Approval is enabled

Next State

```text
PENDING_APPROVAL
```

Business owner receives notification.

---

## PENDING_APPROVAL

Customer Message

```text
Your booking request has been submitted.

Waiting for approval.
```

Business user

Approves

OR

Rejects

---

If Approved

Next State

```text
BOOKING_CONFIRMED
```

---

If Rejected

Next State

```text
BOOKING_CANCELLED
```

---

## BOOKING_CONFIRMED

System sends confirmation.

Example

```text
Your appointment has been confirmed.

Booking ID

BK-100245
```

Next State

```text
COMPLETED
```

---

## BOOKING_CANCELLED

Possible reasons

- Customer cancelled
- Business rejected
- Slot removed

Conversation ends.

---

## REMINDER_SENT

System automatically sends reminders.

Example

```text
Reminder

Your appointment is tomorrow at 10:30 AM.
```

---

## COMPLETED

Appointment completed.

Future options

- Rate Service
- Give Feedback
- Book Again

---

## SESSION_EXPIRED

Session expires after inactivity.

Default

```text
30 Minutes
```

Customer receives

```text
Your previous session has expired.

Please type HI to start again.
```

---

# Valid State Transitions

| Current State | Next State |
|---------------|------------|
| START | GREETING |
| GREETING | SERVICE_SELECTION |
| SERVICE_SELECTION | DATE_SELECTION |
| DATE_SELECTION | SLOT_SELECTION |
| SLOT_SELECTION | BOOKING_CONFIRMATION |
| BOOKING_CONFIRMATION | BOOKING_CONFIRMED |
| BOOKING_CONFIRMATION | PENDING_APPROVAL |
| PENDING_APPROVAL | BOOKING_CONFIRMED |
| PENDING_APPROVAL | BOOKING_CANCELLED |
| BOOKING_CONFIRMED | COMPLETED |
| ANY STATE | SESSION_EXPIRED |

---

# Invalid State Example

Current State

```text
SERVICE_SELECTION
```

Customer replies

```text
10:30 AM
```

System Response

```text
Please select a service first.
```

The state does not change.

---

# State Persistence

Every state change must be saved.

Stored values

- Session ID
- Business ID
- Customer ID
- Current State
- Selected Service
- Selected Date
- Selected Slot
- Booking ID
- Last Updated Time

---

# State Reset

The conversation resets when

- Session expires
- Booking completed
- Booking cancelled
- Customer requests restart

---

# Error Recovery

If an unexpected message is received

Example

```text
asdfgh
```

System replies

```text
Sorry, I didn't understand.

Please choose one of the available options.
```

State remains unchanged.

---

# Business Rules

- Only one active booking flow per customer.
- Customer cannot skip states.
- Every transition must be validated.
- Completed bookings cannot return to previous states.
- Pending bookings require business approval when manual approval is enabled.

---

# Future Enhancements

- AI Intent Detection
- Multi-language State Machine
- Voice Conversation Support
- Smart Suggestions
- Conversation Analytics

---

# Related Documents

- 16-whatsapp-architecture.md
- 17-conversation-engine.md
- 19-message-templates.md
- 20-whatsapp-webhook-processing.md
- 20.1-session-management.md

---

# Revision History

| Version | Date | Description |
|----------|------|-------------|
| 1.0 | July 2026 | Initial Conversation State Machine Design |
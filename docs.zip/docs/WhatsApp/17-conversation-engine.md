# Conversation Engine

**Document ID:** WA-002  
**Project:** Appointment Platform (WhatsApp First SaaS)  
**Version:** 1.0  
**Status:** Draft

---

# Purpose

The Conversation Engine is the core component of the Appointment Platform.

Its responsibility is to understand customer messages, determine the current conversation state, execute business rules, and generate the next response.

The Conversation Engine should not contain business-specific logic (Doctor, Salon, Clinic, Event, etc.). It must work for any business type.

---

# Objectives

- Manage customer conversations
- Support multiple businesses
- Support multiple services
- Handle booking flow
- Handle cancellation flow
- Handle approval flow
- Resume interrupted conversations
- Generate intelligent responses

---

# Responsibilities

The Conversation Engine is responsible for:

- Receiving customer messages
- Loading conversation session
- Identifying customer intent
- Managing conversation state
- Calling business services
- Building WhatsApp responses
- Saving updated session

---

# Out of Scope

The Conversation Engine should NOT:

- Execute SQL queries
- Generate slots
- Book appointments directly
- Send WhatsApp messages directly
- Manage authentication

These responsibilities belong to dedicated services.

---

# High-Level Flow

```text
Customer Message
        │
        ▼
Webhook
        │
        ▼
Conversation Engine
        │
        ▼
Load Session
        │
        ▼
Identify Intent
        │
        ▼
Validate State
        │
        ▼
Execute Business Logic
        │
        ▼
Generate Response
        │
        ▼
Save Session
        │
        ▼
Send WhatsApp Reply
```

---

# Conversation Components

| Component | Responsibility |
|-----------|----------------|
| Session Manager | Load & Save session |
| Intent Resolver | Identify user intent |
| State Manager | Track conversation state |
| Command Handler | Execute commands |
| Response Builder | Generate WhatsApp response |
| Validator | Validate input |
| Business Service | Booking logic |

---

# Customer Journey

```text
Customer

↓

Hi

↓

Greeting

↓

Service Selection

↓

Date Selection

↓

Slot Selection

↓

Booking Confirmation

↓

Appointment Booked

↓

Reminder

↓

Feedback (Future)
```

---

# Supported Customer Intents

| Intent | Description |
|---------|-------------|
| Greeting | Hi, Hello |
| Book Appointment | Start booking |
| View Services | Show available services |
| Select Service | Choose service |
| Select Date | Choose appointment date |
| Select Slot | Choose appointment slot |
| Confirm Booking | Confirm booking |
| Cancel Booking | Cancel appointment |
| View Booking | Show booking details |
| Help | Show help menu |

---

# Session Lifecycle

Every WhatsApp customer has one active conversation session.

```text
Session Created

↓

Session Updated

↓

Session Completed

↓

Session Closed
```

---

# Session Information

Each session stores

- Business ID
- Customer ID
- Mobile Number
- Current State
- Selected Service
- Selected Date
- Selected Slot
- Booking ID
- Last Activity Time

---

# Intent Resolution

Incoming messages are classified into an intent.

Examples

| Customer Message | Intent |
|------------------|--------|
| Hi | Greeting |
| Book Appointment | Start Booking |
| Haircut | Select Service |
| Tomorrow | Select Date |
| 10:30 AM | Select Slot |
| Yes | Confirm Booking |
| Cancel | Cancel Booking |

---

# Conversation Rules

- One active booking flow per customer.
- Resume previous conversation if session exists.
- Ignore duplicate messages.
- Validate every customer input.
- Expired sessions start a new conversation.

---

# Business Rules

The Conversation Engine must:

- Check business status
- Check service availability
- Check slot availability
- Respect booking approval mode
- Respect booking limits
- Respect business working hours

---

# Integration with Services

The Conversation Engine communicates with:

- Customer Service
- Booking Service
- Slot Service
- Service Catalog
- Notification Service

It should never access the database directly.

---

# Response Builder

The Response Builder creates WhatsApp-compatible responses.

Supported response types:

- Text
- Interactive Buttons
- List Messages
- Template Messages
- Media Messages (Future)

---

# Error Handling

If the engine cannot process a message:

- Log the error
- Preserve the session
- Send a friendly error message
- Allow customer to continue

Example

```text
Sorry, I couldn't understand that.

Please choose one of the available options.
```

---

# Session Timeout

Default timeout

```text
30 Minutes
```

If no activity occurs:

- Session expires
- Temporary selections are cleared
- Customer starts a new conversation

---

# Performance Requirements

| Metric | Target |
|---------|---------|
| Message Processing | < 500 ms |
| Session Load | < 100 ms |
| Session Save | < 100 ms |
| Response Generation | < 200 ms |

---

# Logging

Log the following events:

- Conversation Started
- Intent Detected
- State Changed
- Booking Created
- Booking Cancelled
- Session Expired
- Processing Error

---

# Future Enhancements

- AI Intent Detection
- Natural Language Processing
- Voice Message Support
- Image Recognition
- Multi-language Conversations
- Context-aware Responses
- Conversation Analytics

---

# Related Documents

- 16-whatsapp-architecture.md
- 18-conversation-state-machine.md
- 19-message-templates.md
- 20-whatsapp-webhook-processing.md
- 20.1-session-management.md
- 20.2-message-parser.md
- 20.3-command-handler.md

---

# Revision History

| Version | Date | Description |
|----------|------|-------------|
| 1.0 | July 2026 | Initial Conversation Engine Design |
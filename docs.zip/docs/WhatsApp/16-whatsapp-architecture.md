````md
# WhatsApp Architecture

**Document ID:** WA-001  
**Project:** Appointment Platform (WhatsApp First SaaS)  
**Version:** 1.0  
**Status:** Draft

---

# Purpose

This document defines the overall WhatsApp architecture of the Appointment Platform.

The primary objective is to make WhatsApp the primary interface for both customers and business users while keeping a web application available for administration and reporting.

---

# Objectives

- WhatsApp-first platform
- Support multiple businesses
- Fully automated booking flow
- Manual approval support
- Highly scalable architecture
- Event-driven processing
- Cloud native deployment

---

# Scope

## Customer

Customers can

- Start conversation
- View services
- Select service
- Select date
- Select slot
- Confirm booking
- Cancel booking
- View booking
- Receive reminders

---

## Business User

Business users can

- Create services
- Create slots
- Approve bookings
- Reject bookings
- Block dates
- Configure settings
- Receive notifications
- Manage customers

Business users can perform these actions from

- WhatsApp
- Web Application

---

# High Level Architecture

```text
                        +----------------------+
                        |     Customer         |
                        +----------+-----------+
                                   |
                            WhatsApp Message
                                   |
                                   ▼
                      +--------------------------+
                      | Meta WhatsApp Cloud API  |
                      +------------+-------------+
                                   |
                             Webhook Event
                                   |
                                   ▼
                    +-------------------------------+
                    | WhatsApp Webhook Controller   |
                    +---------------+---------------+
                                    |
                                    ▼
                    +-------------------------------+
                    | Conversation Engine           |
                    +---------------+---------------+
                                    |
           +------------------------+------------------------+
           |                        |                        |
           ▼                        ▼                        ▼
   Booking Service          Customer Service         Notification Service
           |                        |                        |
           +------------------------+------------------------+
                                    |
                                    ▼
                           PostgreSQL Database
                                    |
                                    ▼
                           Response Generator
                                    |
                                    ▼
                         WhatsApp Cloud API
                                    |
                                    ▼
                              Customer
```

---

# System Components

| Component | Responsibility |
|------------|---------------|
| WhatsApp Cloud API | Receive and send messages |
| Webhook Controller | Accept webhook requests |
| Conversation Engine | Process conversation |
| Booking Service | Booking logic |
| Slot Service | Slot management |
| Customer Service | Customer management |
| Notification Engine | Send notifications |
| Reminder Engine | Appointment reminders |
| Database | Store business data |
| Admin Web | Business management |

---

# Architecture Layers

```text
Presentation Layer
        │
        ▼
Webhook Layer
        │
        ▼
Conversation Layer
        │
        ▼
Business Layer
        │
        ▼
Data Layer
```

---

# Customer Booking Flow

```text
Customer

↓

Hi

↓

Choose Service

↓

Choose Date

↓

Choose Slot

↓

Booking Request

↓

Auto Approval ?

↓

Yes ------------------> Booking Confirmed

No

↓

Waiting For Business Approval

↓

Approved

↓

Booking Confirmed
```

---

# Business Flow

Business User

- Login Web Panel

OR

- WhatsApp

Can

- Create Slot
- Delete Slot
- Approve Booking
- Reject Booking
- Block Holiday
- View Today's Bookings
- View Pending Bookings

---

# Conversation Engine

The Conversation Engine is responsible for

- Understanding current state
- Validating user input
- Executing business rules
- Generating next response

It does not access the database directly.

---

# State Management

Every customer conversation has a current state.

Example

```text
START

↓

SERVICE_SELECTION

↓

DATE_SELECTION

↓

SLOT_SELECTION

↓

BOOKING_CONFIRMATION

↓

BOOKING_COMPLETED
```

State details are explained in

```
18-conversation-state-machine.md
```

---

# Multi-Tenant Architecture

Every request belongs to one business.

Each business has

- Own Services
- Own Slots
- Own Customers
- Own Bookings
- Own Settings

Business data must never be shared.

---

# WhatsApp Session

Customer session contains

- Mobile Number
- Current State
- Selected Service
- Selected Date
- Selected Slot
- Last Activity Time

---

# Booking Modes

## Auto Approval

Booking is confirmed immediately.

---

## Manual Approval

Booking remains pending.

Business user receives notification.

Business approves.

Customer receives confirmation.

---

# Notification Flow

Notifications are sent for

- Booking Created
- Booking Approved
- Booking Rejected
- Booking Cancelled
- Appointment Reminder

Future

- Promotional Offers
- Feedback Request

---

# Reminder Engine

Reminder examples

24 Hours Before

↓

Reminder Message

2 Hours Before

↓

Reminder Message

Future

↓

Follow-up Message

---

# Admin Web Application

The web application provides

- Dashboard
- Customer Management
- Booking Management
- Slot Management
- Service Management
- WhatsApp Settings
- Reports
- Business Settings

---

# WhatsApp Features

Customer

- Book Appointment
- Cancel Appointment
- View Booking

Business

- Create Slots
- Approve Bookings
- Reject Bookings
- View Today's Schedule

---

# Database Modules

The WhatsApp module interacts with

- Business
- Customer
- Service
- Slot
- Booking
- Conversation Session
- Notification
- Audit Log

---

# Security

- HTTPS Only
- JWT for Admin APIs
- Webhook Verification
- Request Validation
- Business Isolation
- Audit Logging

---

# Scalability

The architecture should support

- Thousands of Businesses
- Millions of Messages
- Multiple API Servers
- Background Workers
- Queue Processing

---

# Future Enhancements

- AI Appointment Assistant
- Voice Message Support
- Image Upload Support
- Google Calendar Integration
- Payment Integration
- Staff Assignment
- Multiple Branches
- Multi-language Conversations
- Analytics Dashboard

---

# Related Documents

- 17-conversation-engine.md
- 18-conversation-state-machine.md
- 19-message-templates.md
- 20-whatsapp-webhook-processing.md
- 21-admin-web-application.md

---

# Revision History

| Version | Date | Description |
|----------|------|-------------|
| 1.0 | July 2026 | Initial WhatsApp Architecture |
````

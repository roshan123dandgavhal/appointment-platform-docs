# WhatsApp Webhook Processing

**Document ID:** WA-005  
**Project:** Appointment Platform (WhatsApp First SaaS)  
**Version:** 1.0  
**Status:** Draft

---

# Purpose

This document defines how incoming WhatsApp webhook requests are received, validated, processed, and responded to.

Every incoming customer message enters the system through the WhatsApp webhook.

---

# Objectives

- Secure webhook endpoint
- Process every message exactly once
- Support asynchronous processing
- Prevent duplicate bookings
- Ensure reliable message delivery
- Maintain complete audit logs

---

# Scope

This document covers:

- Webhook verification
- Incoming message processing
- Event validation
- Session lookup
- Conversation engine
- Database updates
- Outgoing responses
- Error handling
- Retry strategy

---

# High Level Flow

```text
Customer

↓

WhatsApp

↓

Meta WhatsApp Cloud API

↓

Webhook Endpoint

↓

Verify Request

↓

Validate Payload

↓

Store Raw Payload

↓

Queue Message

↓

Conversation Engine

↓

Business Services

↓

Database

↓

Generate Response

↓

WhatsApp Cloud API

↓

Customer
```

---

# Webhook Endpoint

```http
GET  /api/v1/webhooks/whatsapp
```

Purpose

Webhook Verification

---

```http
POST /api/v1/webhooks/whatsapp
```

Purpose

Receive incoming WhatsApp events.

---

# Processing Steps

## Step 1

Receive HTTP Request

↓

Validate HTTPS

↓

Reject HTTP requests.

---

## Step 2

Verify Meta Signature

Validate

- Signature
- Verify Token
- Request Integrity

If invalid

Return

```text
403 Forbidden
```

---

## Step 3

Validate JSON

Ensure

- Valid JSON
- Required fields exist
- Supported event type

---

## Step 4

Store Raw Payload

Save every webhook request.

Table

```text
webhook_events
```

Fields

- Event ID
- Provider
- Payload
- Status
- Received Time

Purpose

- Audit
- Debugging
- Replay Failed Events

---

## Step 5

Check Duplicate Event

Use

```text
messageId
```

If already processed

Return

```text
200 OK
```

Do not process again.

---

## Step 6

Create Processing Job

Push message to queue.

Example

```text
Incoming Message Queue
```

Background worker processes the request.

---

## Step 7

Load Customer Session

Find

- Business
- Customer
- Current Conversation State

If no session exists

Create new session.

---

## Step 8

Conversation Engine

The engine

- Reads current state
- Identifies intent
- Executes business rules
- Generates next state
- Creates response

---

## Step 9

Business Services

Conversation Engine calls

- Customer Service
- Booking Service
- Slot Service
- Notification Service

---

## Step 10

Update Database

Save

- Customer
- Session
- Booking
- Conversation State
- Audit Log

---

## Step 11

Generate WhatsApp Response

Supported Types

- Text
- Interactive Buttons
- List Messages
- Template Messages

---

## Step 12

Send Response

Call

```text
Meta WhatsApp Send Message API
```

Store

- Message ID
- Delivery Status
- Timestamp

---

# Incoming Event Types

| Event | Description |
|--------|-------------|
| Text Message | Customer sends text |
| Button Reply | Customer clicks button |
| List Reply | Customer selects list option |
| Image Message | Future |
| Voice Message | Future |
| Location | Future |
| Contact | Future |

---

# Session Processing

Each request loads

- Session ID
- Current State
- Selected Service
- Selected Date
- Selected Slot
- Last Activity Time

After processing

Save updated session.

---

# Idempotency

Duplicate messages must never create duplicate bookings.

Validation

```text
messageId
```

Rule

One message

↓

One processing

↓

One response

---

# Queue Processing

Purpose

- Faster webhook response
- Better scalability
- Retry support
- Failure isolation

Example

```text
Webhook

↓

Message Queue

↓

Background Worker

↓

Conversation Engine
```

---

# Error Handling

If processing fails

- Log exception
- Update webhook status
- Preserve payload
- Retry processing

Customer receives

```text
Sorry.

Something went wrong.

Please try again.
```

---

# Retry Strategy

Retry only temporary failures.

Examples

- Database unavailable
- WhatsApp API timeout
- Network timeout

Do not retry

- Invalid payload
- Invalid signature
- Unsupported event

---

# Logging

Log

- Event ID
- Message ID
- Business ID
- Customer ID
- Processing Time
- Response Time
- Processing Status

---

# Monitoring

Monitor

- Incoming Requests
- Failed Events
- Duplicate Events
- Queue Length
- Processing Time
- Error Rate
- API Response Time

---

# Security

Every webhook must

- Use HTTPS
- Verify Meta signature
- Validate payload
- Prevent replay attacks
- Log suspicious requests

---

# Performance Targets

| Metric | Target |
|----------|---------|
| Webhook Response | < 500 ms |
| Queue Processing | < 2 sec |
| Conversation Processing | < 1 sec |
| Database Update | < 300 ms |
| Response Delivery | < 2 sec |

---

# Business Rules

- Every webhook must be stored.
- Every webhook must have a unique Event ID.
- Duplicate events must not be processed.
- Webhook endpoint must always return HTTP 200 after successful validation.
- Business logic must execute in background workers.
- Conversation state must be saved after every message.

---

# Future Enhancements

- Dead Letter Queue (DLQ)
- Distributed Queue Processing
- AI Intent Detection
- Voice Message Processing
- Image Recognition
- Multi-region Deployment
- Auto Scaling Workers

---

# Related Documents

- 15-webhook-api.md
- 16-whatsapp-architecture.md
- 17-conversation-engine.md
- 18-conversation-state-machine.md
- 19-message-templates.md
- 20.1-session-management.md
- 20.2-message-parser.md
- 20.3-command-handler.md
- 20.4-state-storage.md

---

# Revision History

| Version | Date | Description |
|----------|------|-------------|
| 1.0 | July 2026 | Initial WhatsApp Webhook Processing Design |
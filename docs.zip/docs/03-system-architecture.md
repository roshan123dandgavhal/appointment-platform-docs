# System Architecture

**Project:** Appointment Platform  
**Document Version:** 1.0  
**Status:** Draft

---

# 1. Overview

The Appointment Platform is a **multi-tenant SaaS application** that enables businesses to manage appointments primarily through **WhatsApp**, while providing a web application for administration and configuration.

The platform is designed to support multiple business types without requiring application code changes.

Examples include:

- Salons
- Clinics
- Hospitals
- Tutors
- Consultants
- Event Management Companies
- Fitness Trainers
- Spas

The platform follows a **configuration-driven architecture**, allowing each business to customize services, slots, approval workflow, and WhatsApp integration.

---

# 2. Architecture Principles

The system follows these core principles:

- Multi-Tenant by Design
- Configuration over Hardcoding
- API First
- WhatsApp First
- Modular Architecture
- Cloud Native
- Secure by Default
- Docker First Development
- Scalable Design

---

# 3. High-Level Architecture

```
                        Customer

                     WhatsApp Message

                            │
                            ▼

                  Meta WhatsApp Cloud API

                            │
                     Webhook Events

                            ▼

                  Appointment Platform API
              (Node.js + Fastify + TypeScript)

        ┌──────────────┬───────────────┬─────────────┐
        │              │               │             │
        ▼              ▼               ▼             ▼

   Booking Module  Customer Module  Service Module  Slot Module

        │              │               │             │

        └──────────────┴───────────────┴─────────────┘

                        Prisma ORM

                            │

                      PostgreSQL Database

                            ▲

                            │

                  React Admin Application

                            │

                     Business Administrator
```

---

# 4. System Components

The platform consists of five major components.

## 4.1 React Admin Application

Purpose:

Administrative portal for business users.

Responsibilities:

- Login
- Business Settings
- WhatsApp Configuration
- Service Management
- Slot Management
- Booking Management
- Customer Management
- Reports (Future)

Technology

- React
- TypeScript
- Vite
- Tailwind CSS

---

## 4.2 Backend API

Purpose

Core business logic.

Responsibilities

- Authentication
- Booking Engine
- WhatsApp Integration
- Business Rules
- Validation
- Notifications

Technology

- Node.js
- Fastify
- Prisma
- TypeScript

---

## 4.3 PostgreSQL

Purpose

Persistent storage.

Stores

- Businesses
- Users
- Customers
- Services
- Slots
- Bookings
- Settings
- WhatsApp Configuration

---

## 4.4 WhatsApp Cloud API

Purpose

Communication with customers.

Responsibilities

- Receive messages
- Send replies
- Deliver booking confirmation
- Deliver approval notifications

---

## 4.5 Cloud Infrastructure

Purpose

Host the application.

Technology

- AWS
- Docker
- GitHub Actions

Future

- Kubernetes
- Load Balancer
- Redis

---

# 5. Multi-Tenant Architecture

The platform is a **single application** serving multiple businesses.

```
                   Appointment Platform

        ┌───────────────────────────────────────┐
        │                                       │
        │          Shared Application           │
        │                                       │
        └───────────────────────────────────────┘

                │            │             │

                ▼            ▼             ▼

          Salon A       Clinic B      Tutor C

         Business 1     Business 2    Business 3
```

Each business has its own:

- Users
- Customers
- Services
- Slots
- Bookings
- WhatsApp Account
- Settings

All business data is isolated using **business_id**.

---

# 6. Backend Modules

The backend is organized into independent modules.

```
src/

    business/

    auth/

    user/

    customer/

    service/

    slot/

    booking/

    whatsapp/

    settings/

    notification/

    common/
```

Each module contains:

- Controller
- Service
- Repository
- Validation
- Routes
- DTO
- Types

---

# 7. Request Flow

## Admin Request

```
Browser

↓

React

↓

REST API

↓

Fastify

↓

Service Layer

↓

Prisma

↓

PostgreSQL
```

---

## Customer Request

```
Customer

↓

WhatsApp

↓

Meta

↓

Webhook

↓

Fastify

↓

Booking Engine

↓

Database

↓

WhatsApp Reply
```

---

# 8. Authentication

Admin users authenticate using:

- Email
- Password

Authentication mechanism:

JWT

Future:

- Google Login
- Microsoft Login

Customers do not authenticate.

Customers are identified using their WhatsApp mobile number.

---

# 9. Authorization

Roles

- Platform Admin
- Business Admin
- Staff (Future)

Every API validates:

- Authentication
- Business Ownership
- Permissions

---

# 10. Database Layer

Prisma ORM is used for database access.

Benefits

- Type Safety
- Migrations
- Relationship Management
- Query Builder

Database

PostgreSQL

---

# 11. WhatsApp Integration

Every business connects its own WhatsApp Business Account.

Incoming webhook contains:

- Phone Number ID
- Customer Mobile Number
- Message
- Timestamp

The platform identifies the business using the Phone Number ID.

Conversation state is maintained during the booking process.

---

# 12. Deployment Architecture

Development

```
Developer

↓

Docker Compose

↓

API

↓

React

↓

PostgreSQL
```

Production

```
Internet

↓

Load Balancer

↓

React

↓

Fastify API

↓

PostgreSQL

↓

AWS Backup
```

---

# 13. Error Handling

The platform handles:

- Invalid requests
- Validation errors
- Booking conflicts
- Expired slots
- WhatsApp API failures
- Authentication failures

Errors are logged and returned using standard API responses.

---

# 14. Logging

The system logs:

- API Requests
- API Responses
- Errors
- WhatsApp Events
- Booking Events
- User Actions

Future

- CloudWatch
- ELK Stack

---

# 15. Scalability

The platform is designed for horizontal scaling.

Future enhancements include:

- Redis Cache
- Queue Processing
- Kubernetes
- Auto Scaling
- CDN
- Read Replicas

---

# 16. Security

Security measures include:

- HTTPS
- JWT Authentication
- Password Hashing
- Role Based Access Control
- Input Validation
- SQL Injection Prevention
- Rate Limiting
- Audit Logs

---

# 17. Repository Structure

```
appointment-platform-docs/

appointment-platform-api/

appointment-platform-web/

appointment-platform-local/
```

---

# 18. Technology Stack

## Backend

- Node.js
- Fastify
- TypeScript
- Prisma ORM

## Frontend

- React
- Vite
- Tailwind CSS

## Database

- PostgreSQL

## Infrastructure

- Docker
- GitHub
- GitHub Actions
- AWS

---

# 19. Future Architecture

Future improvements include:

- Redis
- Background Workers
- Notification Service
- Payment Service
- AI Assistant
- Analytics Service
- Calendar Integration
- Mobile Application
- Public API
- White Label Platform

---

# 20. Architecture Decision Records (ADR)

Major architectural decisions should be documented.

Examples:

- Why Fastify?
- Why Prisma?
- Why PostgreSQL?
- Why Multi-Tenant?
- Why WhatsApp First?
- Why Docker?
- Why AWS?

These decisions help future developers understand the reasoning behind the architecture.

---

# Revision History

| Version | Date | Description |
|----------|------|-------------|
| 1.0 | July 2026 | Initial version |
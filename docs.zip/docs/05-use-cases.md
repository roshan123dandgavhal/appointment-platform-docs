# Use Cases

**Document ID:** UC-001  
**Project:** Appointment Platform  
**Version:** 1.0  
**Status:** Draft

---

# Purpose

This document defines the functional use cases of the Appointment Platform.

It explains how different users interact with the system through WhatsApp and the Admin Web Portal.

---

# Actors

| Actor | Description |
|--------|-------------|
| Customer | End user booking appointments through WhatsApp |
| Business Admin | Business owner or manager |
| Staff (Future) | Employee handling appointments |
| Platform Admin | SaaS platform administrator |
| WhatsApp Cloud API | External messaging service |

---

# Customer Use Cases

## UC-001 - Start Conversation

**Actor**
- Customer

**Trigger**
- Customer sends "Hi" on WhatsApp.

**Preconditions**
- Business WhatsApp number is active.

**Flow**

1. Customer sends "Hi".
2. System identifies the business.
3. System starts a new conversation.
4. System displays available services.

**Post Condition**

Conversation starts successfully.

---

## UC-002 - View Services

**Actor**

Customer

**Flow**

1. System displays available services.
2. Customer selects one service.

**Alternative**

If no services exist, system informs customer.

---

## UC-003 - View Available Dates

**Actor**

Customer

**Flow**

1. Customer selects service.
2. System shows available dates.
3. Customer selects a date.

---

## UC-004 - View Available Slots

**Actor**

Customer

**Flow**

1. Customer selects date.
2. System shows available slots.
3. Customer selects a slot.

---

## UC-005 - Enter Name

**Actor**

Customer

**Condition**

Executed only if:

Ask Customer Name = Enabled

**Flow**

1. System asks customer name.
2. Customer replies.
3. System saves customer details.

---

## UC-006 - Confirm Booking

**Actor**

Customer

**Flow**

1. System displays booking summary.
2. Customer confirms.
3. Booking request is created.

---

## UC-007 - Auto Approval

**Condition**

Auto Approval = Enabled

**Flow**

1. Booking created.
2. Booking marked Confirmed.
3. Confirmation message sent.

---

## UC-008 - Manual Approval

**Condition**

Approval Required

**Flow**

1. Booking status = Pending
2. Admin notified.
3. Customer waits for approval.

---

## UC-009 - Booking Approved

**Actor**

Business Admin

**Flow**

1. Admin approves booking.
2. Booking status updated.
3. Customer receives confirmation.

---

## UC-010 - Booking Rejected

**Actor**

Business Admin

**Flow**

1. Admin rejects booking.
2. Booking status updated.
3. Customer receives rejection message.

---

## UC-011 - Cancel Appointment

**Actor**

Customer

**Flow**

1. Customer requests cancellation.
2. System validates rules.
3. Booking cancelled.
4. Slot becomes available again.

---

# Business Admin Use Cases

## UC-012 - Login

Admin logs into web portal.

---

## UC-013 - Create Service

Admin creates a new service.

Example

- Hair Cut
- Consultation
- Passport Verification

No hardcoded service names.

---

## UC-014 - Update Service

Admin edits service information.

---

## UC-015 - Disable Service

Admin disables service.

Existing bookings remain unchanged.

---

## UC-016 - Create Slots

Admin creates appointment slots.

Supports

- Single Date
- Date Range
- Recurring Slots (Future)

---

## UC-017 - Edit Slot

Admin updates slot details.

---

## UC-018 - Delete Slot

Admin deletes unused slot.

Booked slots cannot be deleted.

---

## UC-019 - View Bookings

Admin views bookings.

Filters

- Date
- Service
- Status
- Customer

---

## UC-020 - Approve Booking

Admin approves pending booking.

---

## UC-021 - Reject Booking

Admin rejects pending booking.

---

## UC-022 - Configure Business

Admin updates

- Business Name
- Timezone
- Currency
- WhatsApp Settings

---

## UC-023 - Configure Booking Rules

Admin configures

- Auto Approval
- Ask Customer Name
- Cancellation Hours
- Booking Availability

---

## UC-024 - Connect WhatsApp

Admin configures

- Phone Number
- Phone Number ID
- Access Token
- Verify Token

---

## UC-025 - View Customers

Admin views customer list.

---

## UC-026 - Search Customers

Admin searches customers using

- Name
- Mobile Number

---

## UC-027 - View Dashboard

Admin views

- Today's Bookings
- Pending Bookings
- Confirmed Bookings
- Total Customers

---

# Platform Admin Use Cases

## UC-028 - Manage Businesses

Platform Admin creates businesses.

---

## UC-029 - Suspend Business

Platform Admin disables business access.

---

## UC-030 - View System Health

Platform Admin monitors

- Businesses
- API Status
- WhatsApp Status

---

# Future Use Cases

## UC-031 - Manage Staff

Assign bookings to staff.

---

## UC-032 - Multiple Branches

Customer selects branch.

---

## UC-033 - Holiday Calendar

Business defines holidays.

---

## UC-034 - Google Calendar Sync

Appointments synchronize automatically.

---

## UC-035 - Online Payment

Customer pays before booking confirmation.

---

## UC-036 - Reminder Messages

Automatic reminder before appointment.

---

## UC-037 - Offers & Discounts

Business creates promotional offers.

---

## UC-038 - AI Assistant

AI answers customer questions.

---

# Use Case Relationships

Customer

```
Start Chat
      ↓
View Services
      ↓
Select Service
      ↓
Select Date
      ↓
Select Slot
      ↓
Enter Name (Optional)
      ↓
Confirm Booking
      ↓
Auto Approval?
      ↓
   Yes      No
    ↓        ↓
Confirmed  Pending
             ↓
      Admin Approval
             ↓
      Confirmed/Rejected
```

---

# Non-Functional Requirements

- Fast response (<2 seconds)
- Secure APIs
- Multi-tenant support
- Mobile-friendly
- WhatsApp-first experience
- High availability
- Scalable architecture

---

# Revision History

| Version | Date | Description |
|----------|------|-------------|
| 1.0 | July 2026 | Initial Use Cases Document |
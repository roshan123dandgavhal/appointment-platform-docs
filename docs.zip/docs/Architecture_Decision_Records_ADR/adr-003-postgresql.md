# ADR-003: Adopt PostgreSQL as the Primary Database

**ADR ID:** ADR-003  
**Title:** Adopt PostgreSQL as the Primary Relational Database  
**Status:** Accepted  
**Date:** July 2026  
**Decision Makers:** Engineering Team

---

# Context

The Appointment Platform requires a reliable, scalable, and ACID-compliant relational database to manage business-critical data.

The database will store

- Businesses
- Users
- Customers
- Services
- Staff
- Time Slots
- Bookings
- Payments
- WhatsApp Conversations
- Notifications
- Audit Logs

The selected database must integrate well with Prisma ORM, Fastify, Docker, Kubernetes, and AWS.

---

# Problem Statement

The platform requires a database that provides

- ACID transactions
- High reliability
- Strong data integrity
- Excellent indexing capabilities
- JSON support
- Scalability
- Backup and recovery options
- Cloud-native deployment

Several database technologies were evaluated.

---

# Decision

The project will use **PostgreSQL** as the primary relational database.

---

# Why PostgreSQL?

PostgreSQL provides

- Excellent reliability
- ACID compliance
- Advanced indexing
- JSON/JSONB support
- Strong community support
- High scalability
- Excellent compatibility with Prisma

---

# Benefits

## ACID Compliance

PostgreSQL guarantees

- Atomicity
- Consistency
- Isolation
- Durability

Benefits

- Reliable booking transactions
- Consistent customer data
- Safe payment processing

---

## Rich SQL Features

PostgreSQL supports

- Views
- Stored Procedures
- Triggers
- Window Functions
- Common Table Expressions (CTEs)

These features simplify reporting and analytics.

---

## JSON Support

PostgreSQL supports JSON and JSONB data types.

Example use cases

- WhatsApp webhook payloads
- Application settings
- Audit metadata
- External API responses

---

## Indexing

Supported index types

- B-Tree
- Hash
- GIN
- GiST
- BRIN

Benefits

- Faster searches
- Efficient filtering
- Improved reporting performance

---

## Concurrency

PostgreSQL uses Multi-Version Concurrency Control (MVCC).

Benefits

- High read/write performance
- Reduced locking
- Better user experience under concurrent load

---

# Alternatives Considered

## MySQL

Pros

- Popular
- Easy to manage
- Large ecosystem

Cons

- Fewer advanced SQL features
- Less flexible JSON capabilities

Decision

Not selected.

---

## MongoDB

Pros

- Flexible document model
- Easy schema evolution

Cons

- Not ideal for transactional booking systems
- Weaker relational modeling

Decision

Not selected.

---

## Microsoft SQL Server

Pros

- Enterprise features
- Strong tooling

Cons

- Higher licensing costs
- Vendor lock-in

Decision

Not selected.

---

## SQLite

Pros

- Lightweight
- Simple setup

Cons

- Not suitable for multi-user production workloads

Decision

Not selected.

---

# Architecture Impact

Database architecture

```text
Fastify

↓

Controllers

↓

Services

↓

Repositories

↓

Prisma ORM

↓

PostgreSQL
```

PostgreSQL stores all transactional business data.

---

# Integration

PostgreSQL integrates with

- Prisma ORM
- Fastify
- Docker
- Kubernetes
- AWS RDS
- GitHub Actions
- Grafana
- Prometheus

---

# Data Model

Major entities

- Business
- User
- Customer
- Service
- Staff
- Booking
- Slot
- Notification
- Conversation
- Payment
- Subscription

---

# Performance Considerations

Best practices

- Create indexes on frequently searched columns.
- Use pagination for large result sets.
- Avoid unnecessary joins.
- Monitor slow queries.
- Use connection pooling.

Performance targets

| Metric | Target |
|---------|---------|
| Simple Query | < 100 ms |
| Booking Creation | < 500 ms |
| Customer Search | < 300 ms |
| Report Generation | < 2 sec |

---

# Backup & Recovery

Strategy

- Automated daily backups
- Point-in-Time Recovery (PITR)
- Multi-AZ backups (AWS RDS)
- Regular restore testing

Recovery objectives

| Metric | Target |
|---------|---------|
| Recovery Point Objective (RPO) | ≤ 15 minutes |
| Recovery Time Objective (RTO) | ≤ 1 hour |

---

# Security Considerations

Security measures

- Private database network
- SSL/TLS connections
- Encrypted storage
- Least-privilege database users
- Strong password policies
- Regular backups
- Audit logging

---

# Risks

Potential risks

- Slow queries with poor indexing
- Storage growth over time
- Connection pool exhaustion
- Long-running transactions

Mitigation

- Regular performance tuning
- Query optimization
- Database monitoring
- Capacity planning

---

# Consequences

Positive

- Reliable transactional database
- Excellent scalability
- Strong SQL capabilities
- Mature ecosystem
- Cloud-native deployment

Negative

- Requires database administration knowledge
- Large reports may need optimization
- Schema changes require migration planning

---

# Future Considerations

Potential enhancements

- Read Replicas
- Database Partitioning
- Logical Replication
- Multi-Region Deployment
- Data Archiving
- Advanced Analytics Warehouse

---

# Related Documents

- 07-database-design.md
- 08-database-schema.md
- 06-backend-architecture.md
- 28-aws-deployment.md
- adr-001-fastify.md
- adr-002-prisma.md

---

# Revision History

| Version | Date | Description |
|----------|------|-------------|
| 1.0 | July 2026 | Initial ADR for adopting PostgreSQL as the primary database |
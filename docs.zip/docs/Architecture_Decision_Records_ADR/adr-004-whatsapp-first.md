# ADR-004: Adopt a WhatsApp-First User Experience

**ADR ID:** ADR-004  
**Title:** Adopt WhatsApp as the Primary Customer Interaction Channel  
**Status:** Accepted  
**Date:** July 2026  
**Decision Makers:** Engineering Team

---

# Context

The Appointment Platform is designed primarily for small and medium-sized businesses that communicate with customers using WhatsApp.

Many businesses already use WhatsApp daily for

- Appointment booking
- Customer inquiries
- Rescheduling
- Reminders
- Promotions
- Customer support

The goal is to provide a seamless booking experience without requiring customers to install a separate mobile application.

---

# Problem Statement

Customers often face challenges with traditional booking systems because they require

- Installing a mobile application
- Creating a new account
- Remembering passwords
- Learning a new interface
- Downloading updates

Businesses also spend considerable time manually responding to appointment requests on WhatsApp.

A conversational booking experience can reduce these challenges while improving customer engagement.

---

# Decision

The platform will adopt a **WhatsApp-first** approach for customer interactions.

Customers will perform most appointment-related activities directly through WhatsApp, while business staff and administrators will use the web application for management and reporting.

---

# Decision Drivers

- High WhatsApp adoption among target customers
- Familiar user experience
- Reduced onboarding effort
- Faster appointment booking
- Lower customer support workload
- Increased booking conversion rate

---

# Customer Journey

```text
Customer

↓

Sends WhatsApp Message

↓

WhatsApp Cloud API

↓

Webhook

↓

Conversation Engine

↓

Booking Engine

↓

Confirmation Message
```

---

# Scope of WhatsApp

Customers can

- View available services
- Select staff (if applicable)
- Choose appointment dates
- Select available time slots
- Confirm bookings
- Reschedule appointments
- Cancel appointments
- Receive reminders
- Receive promotional messages (where permitted)

---

# Web Application Responsibilities

Business users will use the web application to

- Manage bookings
- Manage customers
- Manage services
- Configure business settings
- View reports
- Manage staff
- Configure WhatsApp templates

---

# Benefits

## Better Customer Experience

Customers interact through an application they already use daily.

Benefits

- No additional installation
- Familiar interface
- Faster adoption
- Reduced learning curve

---

## Higher Engagement

WhatsApp messages generally receive higher open and response rates than email or SMS.

Benefits

- Improved reminder effectiveness
- Faster customer responses
- Better booking completion rates

---

## Reduced Operational Effort

Automated conversations reduce manual work.

Examples

- Automatic booking
- Automatic reminders
- Automatic confirmations
- Automatic cancellations

---

## Centralized Communication

All appointment communication is handled through a single channel.

This simplifies customer support and communication history.

---

# Alternatives Considered

## Mobile Application First

Pros

- Full control over user experience
- Push notifications
- Offline capabilities

Cons

- Higher development cost
- App installation required
- Lower adoption for occasional users

Decision

Not selected for the initial product.

---

## Web Portal First

Pros

- Easy to develop
- No app installation

Cons

- Requires customers to visit a website
- Less convenient for conversational booking

Decision

Not selected.

---

## SMS-Based Booking

Pros

- Wide device compatibility

Cons

- Limited interaction
- No rich messaging
- Difficult conversation management

Decision

Not selected.

---

# Architecture Impact

```text
Customer

↓

WhatsApp Cloud API

↓

Webhook

↓

Message Parser

↓

Conversation Engine

↓

Booking Service

↓

PostgreSQL
```

The web application operates independently for business management.

---

# Technical Considerations

Core components

- WhatsApp Cloud API
- Webhook Processing
- Conversation Engine
- Session Management
- State Machine
- Message Templates
- Notification Engine
- Reminder Engine

---

# Business Benefits

- Faster appointment booking
- Lower support costs
- Improved customer retention
- Increased customer satisfaction
- Better automation
- Higher operational efficiency

---

# Risks

Potential risks

- Dependence on WhatsApp platform availability
- Meta API policy changes
- Conversation-based pricing
- Template approval requirements
- Message delivery limitations

Mitigation

- Modular integration layer
- Retry mechanisms
- Monitoring and alerting
- Alternative notification channels (Email/SMS) in future releases

---

# Consequences

Positive

- Familiar customer experience
- Higher engagement
- Faster onboarding
- Reduced manual operations
- Increased automation

Negative

- Reliance on third-party messaging platform
- Some advanced workflows may require web application support
- Ongoing WhatsApp conversation costs

---

# Future Considerations

Potential enhancements

- AI-powered chatbot
- Voice message support
- Multi-language conversations
- WhatsApp payment integration
- Rich media booking flows
- Integration with additional messaging platforms (Telegram, Messenger, SMS)

---

# Related Documents

- 15-webhook-api.md
- 16-whatsapp-architecture.md
- 17-conversation-engine.md
- 18-conversation-state-machine.md
- 19-message-templates.md
- 20-whatsapp-webhook-processing.md
- 20.5-interactive-messages.md
- 20.6-notification-engine.md

---

# Revision History

| Version | Date | Description |
|----------|------|-------------|
| 1.0 | July 2026 | Initial ADR for adopting a WhatsApp-first architecture |
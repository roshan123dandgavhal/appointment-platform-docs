# ADR-006: Adopt Amazon Web Services (AWS) as the Cloud Platform

**ADR ID:** ADR-006  
**Title:** Adopt AWS as the Primary Cloud Infrastructure Provider  
**Status:** Accepted  
**Date:** July 2026  
**Decision Makers:** Engineering Team

---

# Context

The Appointment Platform requires a cloud platform that provides high availability, scalability, security, and managed services.

The platform will host

- Backend APIs
- Admin Web Application
- PostgreSQL Database
- File Storage
- Background Workers
- Monitoring
- CI/CD Deployments

The infrastructure should support future growth from a small SaaS application to a large multi-tenant platform.

---

# Problem Statement

The cloud platform should provide

- Managed Kubernetes
- Managed PostgreSQL
- Object Storage
- Identity and Access Management
- Monitoring
- Auto Scaling
- Disaster Recovery
- Global Availability

Several cloud providers were evaluated.

---

# Decision

The project will use **Amazon Web Services (AWS)** as the primary cloud platform.

---

# Why AWS?

AWS provides

- Mature cloud services
- Global infrastructure
- High availability
- Strong security
- Excellent scalability
- Managed services
- Broad ecosystem

---

# AWS Services Used

| Service | Purpose |
|----------|----------|
| Amazon EKS | Kubernetes Cluster |
| Amazon EC2 | Worker Nodes (if self-managed) |
| Amazon RDS PostgreSQL | Primary Database |
| Amazon S3 | File Storage |
| Amazon CloudWatch | Monitoring & Logs |
| AWS IAM | Identity & Access Management |
| AWS Secrets Manager | Secret Storage |
| AWS Route 53 | DNS Management |
| AWS Certificate Manager (ACM) | SSL/TLS Certificates |
| Application Load Balancer (ALB) | Traffic Distribution |

---

# Benefits

## Managed Infrastructure

AWS provides managed services that reduce operational overhead.

Benefits

- Automatic updates (where applicable)
- High availability
- Simplified maintenance
- Faster provisioning

---

## Scalability

Infrastructure can scale automatically based on demand.

Examples

- Horizontal Pod Autoscaler
- Cluster Autoscaler
- RDS storage scaling
- Load balancer traffic distribution

---

## Security

AWS provides enterprise-grade security features.

Includes

- IAM Roles
- Security Groups
- VPC Isolation
- Encryption at Rest
- Encryption in Transit
- Audit Logging

---

## Global Availability

Applications can be deployed across multiple Availability Zones and Regions.

Benefits

- High availability
- Disaster recovery
- Reduced downtime
- Lower latency for global users

---

# Alternatives Considered

## Microsoft Azure

Pros

- Strong enterprise integration
- Excellent Microsoft ecosystem

Cons

- Team has more AWS experience
- Different managed service ecosystem

Decision

Not selected.

---

## Google Cloud Platform (GCP)

Pros

- Strong Kubernetes support
- Competitive pricing

Cons

- Smaller service ecosystem for current team familiarity

Decision

Not selected.

---

## Self-Hosted Infrastructure

Pros

- Full infrastructure control
- Potential long-term cost savings

Cons

- High operational effort
- Infrastructure maintenance
- Scalability challenges

Decision

Not selected.

---

# Architecture Impact

```text
Internet

↓

Route 53

↓

Application Load Balancer

↓

Amazon EKS

↓

Fastify API

↓

Prisma ORM

↓

Amazon RDS PostgreSQL

↓

Amazon S3
```

---

# Infrastructure Components

Production architecture

- Amazon EKS
- Amazon RDS PostgreSQL
- Amazon S3
- AWS Secrets Manager
- Amazon CloudWatch
- AWS IAM
- Application Load Balancer
- Route 53

---

# Deployment Strategy

Applications are deployed using

```text
GitHub

↓

GitHub Actions

↓

Docker Build

↓

Container Registry

↓

Helm Deployment

↓

Amazon EKS
```

---

# Monitoring

Monitoring stack

- Amazon CloudWatch
- Prometheus
- Grafana
- Application logs
- Kubernetes metrics

Monitor

- CPU
- Memory
- API latency
- Database performance
- Error rates
- Pod health

---

# Backup & Recovery

Strategy

- Automated RDS backups
- Point-in-Time Recovery (PITR)
- S3 Versioning
- Infrastructure as Code
- Multi-AZ deployment

Recovery targets

| Metric | Target |
|---------|---------|
| Recovery Point Objective (RPO) | ≤ 15 minutes |
| Recovery Time Objective (RTO) | ≤ 1 hour |

---

# Security Considerations

AWS security practices

- Least-privilege IAM policies
- Private subnets for databases
- HTTPS only
- Security Groups
- Secret rotation
- Encryption using AWS-managed keys
- Audit logging with CloudTrail (recommended)

---

# Performance Considerations

Performance targets

| Metric | Target |
|---------|---------|
| API Response | < 500 ms |
| Dashboard Load | < 2 sec |
| Database Query | < 100 ms |
| Availability | 99.9% |

Optimization strategies

- Auto Scaling
- Load Balancing
- Caching
- Database indexing
- CDN support (future)

---

# Risks

Potential risks

- Vendor lock-in
- Cloud cost growth
- Service limits
- Regional outages

Mitigation

- Infrastructure as Code
- Cost monitoring
- Multi-AZ deployment
- Regular backup testing

---

# Consequences

Positive

- High scalability
- Managed infrastructure
- Strong security
- Reliable cloud services
- Broad integration ecosystem

Negative

- Cloud costs require monitoring
- AWS service learning curve
- Potential vendor-specific implementations

---

# Future Considerations

Potential enhancements

- Multi-Region deployment
- AWS WAF
- Amazon ElastiCache (Redis)
- Amazon EventBridge
- AWS Lambda
- AWS Bedrock for AI features
- CloudFront CDN
- Blue/Green deployments

---

# Related Documents

- 26-docker.md
- 27-github-actions.md
- 28-aws-deployment.md
- 29-production-readiness.md
- 29.3-monitoring.md
- 29.9-security.md
- adr-001-fastify.md
- adr-002-prisma.md
- adr-003-postgresql.md

---

# Revision History

| Version | Date | Description |
|----------|------|-------------|
| 1.0 | July 2026 | Initial ADR for adopting AWS as the primary cloud platform |
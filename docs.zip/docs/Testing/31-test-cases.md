# Test Cases

**Document ID:** QA-002  
**Project:** Appointment Platform (WhatsApp First SaaS)  
**Version:** 1.0  
**Status:** Draft

---

# Purpose

This document defines the functional test cases for the Appointment Platform.

The objective is to verify that every module behaves according to the business requirements before deployment.

---

# Objectives

- Validate business requirements
- Verify application functionality
- Prevent production defects
- Ensure application stability
- Support regression testing

---

# Scope

This document includes test cases for

- Authentication
- Authorization
- Business Management
- Customer Management
- Service Management
- Slot Management
- Booking Management
- WhatsApp Integration
- Dashboard
- Reports
- Settings

---

# Test Case Format

| Field | Description |
|---------|-------------|
| Test Case ID | Unique Identifier |
| Module | Feature Name |
| Test Scenario | What is being tested |
| Preconditions | Required setup |
| Test Steps | Steps to execute |
| Expected Result | Expected outcome |
| Priority | High / Medium / Low |
| Status | Pass / Fail / Blocked |

---

# Authentication Test Cases

## TC-AUTH-001

| Field | Value |
|------|-------|
| Module | Authentication |
| Scenario | Valid Login |
| Priority | High |

**Steps**

1. Open Login Page
2. Enter valid email
3. Enter valid password
4. Click Login

**Expected Result**

- Login successful
- Dashboard displayed
- JWT generated

---

## TC-AUTH-002

**Scenario**

Invalid Password

**Expected Result**

- Error message displayed
- Login denied

---

## TC-AUTH-003

**Scenario**

Missing Email

**Expected Result**

- Validation error shown

---

## TC-AUTH-004

**Scenario**

Logout

**Expected Result**

- Session terminated
- Redirect to Login page

---

# Authorization Test Cases

## TC-AUTHZ-001

**Scenario**

Receptionist tries to delete Business

**Expected Result**

Access Denied

---

## TC-AUTHZ-002

**Scenario**

Business Owner updates Services

**Expected Result**

Operation successful

---

## TC-AUTHZ-003

**Scenario**

Staff accesses Reports

**Expected Result**

Permission denied

---

# Business Module

## TC-BUS-001

**Scenario**

Create Business

**Expected Result**

Business created successfully

---

## TC-BUS-002

**Scenario**

Update Business Details

**Expected Result**

Business updated successfully

---

## TC-BUS-003

**Scenario**

Delete Business

**Expected Result**

Business deleted after confirmation

---

# Customer Module

## TC-CUST-001

**Scenario**

Create Customer

**Expected Result**

Customer saved successfully

---

## TC-CUST-002

**Scenario**

Duplicate Mobile Number

**Expected Result**

Duplicate validation message

---

## TC-CUST-003

**Scenario**

Search Customer

**Expected Result**

Matching customers displayed

---

## TC-CUST-004

**Scenario**

Update Customer

**Expected Result**

Customer updated

---

# Service Module

## TC-SRV-001

**Scenario**

Create Service

**Expected Result**

Service created

---

## TC-SRV-002

**Scenario**

Update Service Price

**Expected Result**

Price updated successfully

---

## TC-SRV-003

**Scenario**

Deactivate Service

**Expected Result**

Service hidden from booking

---

# Slot Management

## TC-SLOT-001

**Scenario**

Create Daily Slots

**Expected Result**

Slots generated

---

## TC-SLOT-002

**Scenario**

Create Holiday

**Expected Result**

Slots unavailable

---

## TC-SLOT-003

**Scenario**

Edit Slot Time

**Expected Result**

Slot updated

---

## TC-SLOT-004

**Scenario**

Delete Slot

**Expected Result**

Slot removed

---

# Booking Module

## TC-BOOK-001

**Scenario**

Create Booking

**Expected Result**

Booking confirmed

---

## TC-BOOK-002

**Scenario**

Book Already Reserved Slot

**Expected Result**

Booking rejected

---

## TC-BOOK-003

**Scenario**

Cancel Booking

**Expected Result**

Slot becomes available

---

## TC-BOOK-004

**Scenario**

Reschedule Booking

**Expected Result**

Booking updated

---

## TC-BOOK-005

**Scenario**

Approve Pending Booking

**Expected Result**

Booking confirmed

---

# WhatsApp Module

## TC-WA-001

**Scenario**

Customer sends "Hi"

**Expected Result**

Welcome message received

---

## TC-WA-002

**Scenario**

Customer selects Service

**Expected Result**

Available slots displayed

---

## TC-WA-003

**Scenario**

Customer books appointment

**Expected Result**

Confirmation message sent

---

## TC-WA-004

**Scenario**

Webhook receives message

**Expected Result**

Message processed successfully

---

## TC-WA-005

**Scenario**

Reminder sent before appointment

**Expected Result**

Reminder delivered successfully

---

# Dashboard

## TC-DASH-001

**Scenario**

Dashboard loads

**Expected Result**

Statistics displayed

---

## TC-DASH-002

**Scenario**

Today's bookings displayed

**Expected Result**

Booking list visible

---

# Reports

## TC-REP-001

**Scenario**

Generate Booking Report

**Expected Result**

Report generated

---

## TC-REP-002

**Scenario**

Export CSV

**Expected Result**

CSV downloaded

---

# Settings

## TC-SET-001

**Scenario**

Update Business Settings

**Expected Result**

Settings saved

---

## TC-SET-002

**Scenario**

Configure WhatsApp

**Expected Result**

Configuration validated

---

# Notification Module

## TC-NOT-001

**Scenario**

Booking Confirmation Notification

**Expected Result**

Customer receives notification

---

## TC-NOT-002

**Scenario**

Booking Cancellation Notification

**Expected Result**

Cancellation message sent

---

# Validation Test Cases

| ID | Scenario | Expected Result |
|----|----------|----------------|
| TC-VAL-001 | Empty Required Field | Validation Error |
| TC-VAL-002 | Invalid Mobile Number | Validation Error |
| TC-VAL-003 | Invalid Email | Validation Error |
| TC-VAL-004 | Invalid Date | Validation Error |

---

# API Test Cases

| ID | Scenario | Expected Result |
|----|----------|----------------|
| TC-API-001 | GET API | 200 OK |
| TC-API-002 | POST API | Record Created |
| TC-API-003 | Invalid JWT | 401 Unauthorized |
| TC-API-004 | Forbidden Access | 403 Forbidden |
| TC-API-005 | Invalid Request | 400 Bad Request |

---

# Database Test Cases

| ID | Scenario | Expected Result |
|----|----------|----------------|
| TC-DB-001 | Create Record | Record Saved |
| TC-DB-002 | Update Record | Record Updated |
| TC-DB-003 | Delete Record | Record Removed |
| TC-DB-004 | Transaction Rollback | No Partial Data |

---

# Security Test Cases

| ID | Scenario | Expected Result |
|----|----------|----------------|
| TC-SEC-001 | SQL Injection | Blocked |
| TC-SEC-002 | XSS Attack | Blocked |
| TC-SEC-003 | Invalid JWT | Access Denied |
| TC-SEC-004 | Rate Limit Exceeded | HTTP 429 |

---

# Performance Test Cases

| ID | Scenario | Expected Result |
|----|----------|----------------|
| TC-PERF-001 | Login Response | < 1 sec |
| TC-PERF-002 | Booking API | < 500 ms |
| TC-PERF-003 | Dashboard Load | < 2 sec |

---

# Smoke Test Checklist

- Application Starts
- Login Successful
- Dashboard Loads
- Create Booking
- Create Customer
- WhatsApp Connected
- Reports Working

---

# Regression Test Checklist

Verify

- Login
- Customer Management
- Service Management
- Slot Management
- Booking Flow
- Reports
- WhatsApp Integration
- Notifications

---

# Test Execution Status

| Status | Description |
|---------|-------------|
| Not Started | Test not executed |
| In Progress | Execution started |
| Passed | Test passed |
| Failed | Test failed |
| Blocked | Waiting for dependency |

---

# Best Practices

- Every feature must have test cases.
- Maintain unique test case IDs.
- Automate repetitive test cases.
- Update test cases after requirement changes.
- Execute regression tests before every release.
- Record defects with screenshots and logs.

---

# Related Documents

- 30-testing-strategy.md
- 31.1-test-execution.md
- 32-performance-testing.md
- 13-error-handling.md
- 29-production-readiness.md

---

# Revision History

| Version | Date | Description |
|----------|------|-------------|
| 1.0 | July 2026 | Initial Test Cases Documentation |
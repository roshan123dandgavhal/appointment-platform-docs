# Product Requirements Document (PRD)

**Project:** Appointment Platform  
**Version:** 0.1 (MVP)  
**Status:** Draft  
**Author:** Roshan Dandgavhal  
**Last Updated:** July 2026

---

# 1. Introduction

## Purpose

The purpose of this project is to build a **multi-tenant SaaS appointment booking platform** where businesses can manage appointments primarily through **WhatsApp**, while using a web application for administration and configuration.

The platform should support multiple business domains without changing the application code.

Examples:

- Salon
- Clinic
- Doctor
- Tutor
- Consultant
- Event Management
- Fitness Trainer
- Spa
- Driving School

The system must be configurable enough that adding a new business type requires configuration instead of development.

---

# 2. Vision

To become a flexible appointment booking platform that allows businesses to manage appointments directly from WhatsApp while providing customers with a simple booking experience.

---

# 3. Problem Statement

Many small and medium businesses receive appointment requests through WhatsApp manually.

Common problems include:

- Double booking
- Missed messages
- Manual confirmations
- No appointment history
- No reminders
- Difficult schedule management

Businesses need a simple solution that works with the communication tool they already use.

---

# 4. Goals

## Business Goals

- Reduce manual appointment management.
- Improve customer experience.
- Automate appointment booking.
- Support multiple business types.
- Build a SaaS platform.
- Minimize administrative work.

---

## Technical Goals

- Configuration-driven platform.
- Multi-tenant architecture.
- API-first design.
- WhatsApp-first communication.
- Scalable architecture.
- Cloud-ready deployment.

---

# 5. Target Users

## Business Owner

Responsible for managing the business.

Examples:

- Salon Owner
- Doctor
- Tutor
- Consultant

Responsibilities:

- Configure business
- Manage services
- View appointments
- Approve bookings
- Manage settings

---

## Staff Member (Future)

Responsible for providing services.

Examples:

- Barber
- Doctor
- Trainer

---

## Customer

Books appointments through WhatsApp.

No login required.

---

# 6. User Roles

| Role | Description |
|------|-------------|
| Super Admin | Platform administrator |
| Business Admin | Business owner |
| Staff | Employee (Future) |
| Customer | End user |

---

# 7. Functional Requirements

## Business Management

The system shall allow businesses to:

- Register
- Login
- Configure profile
- Configure WhatsApp
- Configure working hours
- Configure holidays
- Configure appointment settings

---

## Service Management

Business users shall be able to:

- Create service
- Edit service
- Delete service
- Enable/Disable service
- Set appointment duration

---

## Slot Management

Business users shall be able to:

- Create slots
- Edit slots
- Delete slots
- Create recurring slots
- Set slot capacity

---

## Booking

Customers shall be able to:

- View services
- View available dates
- View available slots
- Book appointment
- Receive confirmation

---

## Approval Workflow

System shall support:

- Auto Approval
- Manual Approval

---

## Customer Management

System shall maintain:

- Customer Name
- Mobile Number
- Booking History

---

## Notifications

Customers shall receive:

- Booking Confirmation
- Booking Rejection
- Reminder (Future)
- Cancellation (Future)

---

# 8. Non-Functional Requirements

## Performance

- API Response < 500ms
- Booking confirmation < 5 seconds

---

## Availability

Target:

99.9%

---

## Scalability

Support:

- Thousands of businesses
- Millions of bookings

---

## Security

- HTTPS
- JWT Authentication
- Password Encryption
- Secure Secrets
- Role-based Access

---

## Maintainability

- Modular architecture
- Documentation
- Automated testing
- CI/CD

---

# 9. Business Rules

- Every business is isolated.
- Every service belongs to one business.
- Every slot belongs to one business.
- Every booking belongs to one business.
- Customers cannot book past slots.
- Inactive services cannot be booked.
- Full slots cannot be booked.
- Auto Approval immediately confirms bookings.
- Manual Approval requires business approval.

---

# 10. Assumptions

- Every business has one WhatsApp Business Account.
- Every customer has a WhatsApp account.
- Internet connection is available.
- Business administrators use the web application.

---

# 11. Constraints

- WhatsApp communication depends on Meta APIs.
- Customer interaction happens primarily through WhatsApp.
- MVP supports only one WhatsApp number per business.

---

# 12. Out of Scope (MVP)

The following features are not included in the MVP:

- Online Payments
- AI Assistant
- Multiple Branches
- Staff Scheduling
- Google Calendar Sync
- Email Notifications
- SMS Notifications
- Mobile Application
- Customer Web Portal

---

# 13. Future Scope

Future releases may include:

- Holiday Calendar
- Working Hours Templates
- Automatic Slot Generation
- Staff Assignment
- Multiple Branches
- Google Calendar Integration
- Outlook Calendar Integration
- Payment Gateway
- WhatsApp Reminders
- Email Notifications
- SMS Notifications
- Offers & Coupons
- Customer Loyalty Program
- Waitlist
- Dynamic Forms
- AI Assistant
- Reports
- Analytics
- Public APIs
- Mobile Application
- White Label Solution

---

# 14. Success Metrics

The platform will be considered successful when:

- Businesses can create services.
- Businesses can create appointment slots.
- Customers can book appointments through WhatsApp.
- Businesses can approve appointments.
- Customers receive confirmation messages.
- The system prevents double booking.

---

# 15. MVP Scope

Included:

- Multi-tenant architecture
- Business management
- WhatsApp integration
- Service management
- Slot management
- Appointment booking
- Auto Approval
- Manual Approval
- Admin web application

Excluded:

- Payments
- AI
- Calendar integrations
- Reports
- Analytics

---

# 16. Technology Stack

## Backend

- Node.js
- Fastify
- TypeScript
- Prisma ORM
- PostgreSQL

## Frontend

- React
- Vite
- Tailwind CSS

## Infrastructure

- Docker
- GitHub
- GitHub Actions
- AWS

---

# 17. Guiding Principles

1. Configuration over hardcoding.
2. Multi-tenant by design.
3. API-first architecture.
4. WhatsApp-first customer experience.
5. Scalable and cloud-ready.
6. Clean and maintainable codebase.
7. Security by default.
8. Documentation-driven development.

---

# 18. Conclusion

The Appointment Platform aims to provide a configurable, scalable, and business-friendly appointment booking solution centered around WhatsApp. The MVP focuses on validating the business idea quickly while establishing a solid technical foundation that can evolve into a full SaaS platform supporting multiple industries and advanced capabilities.
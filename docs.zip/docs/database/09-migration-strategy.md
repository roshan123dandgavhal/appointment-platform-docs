# Database Migration Strategy

**Document ID:** DB-003  
**Project:** Appointment Platform  
**Version:** 1.0  
**Status:** Draft

---

# Purpose

This document defines the database migration strategy for the Appointment Platform.

The objective is to ensure database changes are:

- Safe
- Version controlled
- Repeatable
- Rollback friendly
- Automated

---

# Technology

| Item | Value |
|------|-------|
| Database | PostgreSQL |
| ORM | Prisma |
| Migration Tool | Prisma Migrate |
| Deployment | Docker |
| Source Control | GitHub |

---

# Migration Goals

- Version-controlled schema changes
- Zero manual SQL in production
- Repeatable deployments
- Easy rollback
- Environment consistency

---

# Environments

| Environment | Purpose |
|------------|----------|
| Local | Developer machine |
| Development | Shared development environment |
| QA | Testing |
| Staging | Pre-production |
| Production | Live environment |

---

# Migration Folder Structure

```text
prisma/

├── migrations/
│   ├── 202607180001_initial_schema/
│   ├── 202607190001_add_services/
│   ├── 202607200001_add_slots/
│   └── migration_lock.toml
│
├── schema.prisma
└── seed.ts
```

---

# Migration Naming Convention

Format

```text
YYYYMMDDHHMM_description
```

Examples

```text
202607180001_initial_schema

202607190001_add_customer_table

202607200001_add_booking_table

202607210001_add_notifications
```

Use lowercase with underscores.

---

# Initial Migration

The first migration should create:

- businesses
- business_settings
- business_whatsapp
- users
- roles
- customers
- service_categories
- services
- slots
- bookings
- conversation_state
- notifications
- audit_logs

---

# Migration Rules

- One logical change per migration
- Never modify an existing migration
- Create a new migration for every change
- Commit migrations to Git
- Review generated SQL before applying

---

# Local Development Workflow

1. Update `schema.prisma`
2. Generate migration
3. Apply migration locally
4. Test changes
5. Commit migration to Git

---

# Deployment Workflow

```text
Developer
      │
      ▼
Update schema.prisma
      │
      ▼
Generate Migration
      │
      ▼
Commit Code
      │
      ▼
Pull Request
      │
      ▼
Code Review
      │
      ▼
Merge to Main
      │
      ▼
CI/CD Pipeline
      │
      ▼
Run Database Migration
      │
      ▼
Deploy Application
```

---

# Migration Order

Always create database objects in the following order:

1. Enums
2. Tables
3. Primary Keys
4. Foreign Keys
5. Indexes
6. Constraints
7. Seed Data

---

# Rollback Strategy

Every migration should have a rollback plan.

Example:

Migration

```text
Add offers table
```

Rollback

```text
Drop offers table
```

Never delete production data during rollback unless explicitly planned.

---

# Seed Data

Seed only required reference data.

Examples

- Roles
- Booking Status
- Slot Status
- Notification Types

Do NOT seed:

- Businesses
- Customers
- Bookings
- Slots

---

# Schema Change Types

## Safe Changes

- Add table
- Add nullable column
- Add index
- Add new enum value
- Add foreign key

---

## Risky Changes

- Rename column
- Remove column
- Change data type
- Remove table
- Remove enum value

These require additional testing and migration planning.

---

# Data Migration

If existing data must be transformed:

1. Backup database
2. Create migration script
3. Validate transformed data
4. Deploy
5. Verify results

Example:

```text
Split customer_name

Before

John Smith

After

first_name = John

last_name = Smith
```

---

# Backup Strategy

Before every production migration:

- Create database snapshot
- Verify backup completion
- Store backup securely
- Record backup reference

---

# Validation Checklist

Before applying a migration:

- Schema compiles successfully
- Migration generated successfully
- SQL reviewed
- Foreign keys verified
- Indexes verified
- Seed script tested
- Rollback plan documented

---

# CI/CD Integration

Migration process:

```text
Git Push
      │
      ▼
GitHub Actions
      │
      ▼
Run Tests
      │
      ▼
Build Application
      │
      ▼
Apply Database Migration
      │
      ▼
Deploy Application
```

Application deployment should stop if migration fails.

---

# Production Rules

- Never modify production database manually.
- Always use migration scripts.
- Never skip a migration.
- Never delete migration history.
- Apply migrations during maintenance windows if required.
- Monitor application after deployment.

---

# Future Migration Examples

## Version 1.1

- Add staff table
- Add working_hours table
- Add holidays table

---

## Version 1.2

- Add branches
- Add reminder_jobs
- Add google_calendar_sync

---

## Version 2.0

- Add payments
- Add invoices
- Add subscriptions
- Add offers
- Add coupons
- Add AI conversations

---

# Best Practices

- Keep migrations small and focused.
- Test migrations on development and staging before production.
- Review generated SQL.
- Backup production before deployment.
- Keep migration history in Git.
- Use Prisma Migrate for all schema changes.
- Never edit previously executed migrations.

---

# Revision History

| Version | Date | Description |
|----------|------|-------------|
| 1.0 | July 2026 | Initial Database Migration Strategy |
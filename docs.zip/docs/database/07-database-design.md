# Database Design

**Document ID:** DB-001  
**Project:** Appointment Platform  
**Version:** 1.0  
**Status:** Draft

---

# Purpose

This document defines the logical database design for the Appointment Platform.

The database is designed to support:

- Multi-Tenant SaaS
- WhatsApp-first appointment booking
- Configurable businesses
- High scalability
- Extensibility for future modules

---

# Database Technology

| Item | Value |
|------|-------|
| Database | PostgreSQL |
| ORM | Prisma |
| Language | TypeScript |
| Backend | Fastify |
| Migration | Prisma Migrate |

---

# Design Principles

- Multi-Tenant Architecture
- UUID Primary Keys
- Soft Delete Support
- Audit Columns
- Optimized Indexing
- Foreign Key Constraints
- Configuration Driven
- No Hardcoded Business Logic

---

# Database Naming Convention

## Tables

Plural

Example

- businesses
- users
- services
- bookings

---

## Columns

snake_case

Example

- first_name
- created_at
- business_id

---

## Primary Key

```
id
```

UUID

---

## Foreign Key

```
business_id
customer_id
service_id
slot_id
```

---

## Timestamp Columns

```
created_at

updated_at

deleted_at
```

---

# Multi-Tenant Strategy

Every business has isolated data.

Almost every table contains

```
business_id
```

Example

```
Business A

Customers
Bookings
Services

Business B

Customers
Bookings
Services
```

No business can access another business's data.

---

# Core Tables

## 1. businesses

Stores tenant information.

Columns

| Column | Type |
|---------|------|
| id | UUID |
| name | VARCHAR |
| slug | VARCHAR |
| email | VARCHAR |
| phone | VARCHAR |
| timezone | VARCHAR |
| currency | VARCHAR |
| status | VARCHAR |
| created_at | TIMESTAMP |
| updated_at | TIMESTAMP |

Relationships

- Has many Users
- Has many Customers
- Has many Services
- Has many Bookings

---

## 2. business_settings

Stores configurable settings.

Columns

| Column | Type |
|---------|------|
| id | UUID |
| business_id | UUID |
| auto_approve_booking | BOOLEAN |
| ask_customer_name | BOOLEAN |
| cancellation_hours | INTEGER |
| booking_window_days | INTEGER |
| slot_duration | INTEGER |
| created_at | TIMESTAMP |

---

## 3. business_whatsapp

Stores WhatsApp Business configuration.

Columns

| Column | Type |
|---------|------|
| id | UUID |
| business_id | UUID |
| phone_number | VARCHAR |
| phone_number_id | VARCHAR |
| access_token | TEXT |
| verify_token | TEXT |
| webhook_url | TEXT |
| status | VARCHAR |

---

## 4. users

Business users.

Columns

| Column | Type |
|---------|------|
| id | UUID |
| business_id | UUID |
| first_name | VARCHAR |
| last_name | VARCHAR |
| email | VARCHAR |
| password_hash | TEXT |
| role | VARCHAR |
| status | VARCHAR |

---

## 5. roles

System roles.

Example

- Owner
- Admin
- Manager
- Receptionist

Columns

| Column | Type |
|---------|------|
| id | UUID |
| business_id | UUID |
| name | VARCHAR |
| description | TEXT |

---

## 6. customers

Stores WhatsApp customers.

Columns

| Column | Type |
|---------|------|
| id | UUID |
| business_id | UUID |
| mobile_number | VARCHAR |
| name | VARCHAR |
| language | VARCHAR |
| created_at | TIMESTAMP |

Rules

- Mobile number must be unique within a business.
- Name may be optional.

---

## 7. service_categories

Groups services.

Example

- Consultation
- Hair Care
- Therapy

Columns

| Column | Type |
|---------|------|
| id | UUID |
| business_id | UUID |
| name | VARCHAR |
| description | TEXT |

---

## 8. services

Bookable services.

Columns

| Column | Type |
|---------|------|
| id | UUID |
| business_id | UUID |
| category_id | UUID |
| name | VARCHAR |
| duration_minutes | INTEGER |
| price | DECIMAL |
| color | VARCHAR |
| active | BOOLEAN |

---

## 9. slots

Appointment availability.

Columns

| Column | Type |
|---------|------|
| id | UUID |
| business_id | UUID |
| service_id | UUID |
| slot_date | DATE |
| start_time | TIME |
| end_time | TIME |
| capacity | INTEGER |
| booked_count | INTEGER |
| status | VARCHAR |

Rules

- Capacity >= booked_count
- Slot cannot be booked if full.

---

## 10. bookings

Appointment records.

Columns

| Column | Type |
|---------|------|
| id | UUID |
| business_id | UUID |
| customer_id | UUID |
| service_id | UUID |
| slot_id | UUID |
| booking_number | VARCHAR |
| status | VARCHAR |
| notes | TEXT |
| created_at | TIMESTAMP |

Status

- Pending
- Confirmed
- Rejected
- Cancelled
- Completed
- No Show

---

## 11. conversation_state

Stores WhatsApp conversation progress.

Columns

| Column | Type |
|---------|------|
| id | UUID |
| business_id | UUID |
| customer_id | UUID |
| current_step | VARCHAR |
| payload | JSONB |
| expires_at | TIMESTAMP |

---

## 12. notifications

Stores outgoing notifications.

Columns

| Column | Type |
|---------|------|
| id | UUID |
| business_id | UUID |
| customer_id | UUID |
| booking_id | UUID |
| type | VARCHAR |
| channel | VARCHAR |
| message | TEXT |
| status | VARCHAR |
| sent_at | TIMESTAMP |

---

## 13. audit_logs

Stores audit history.

Columns

| Column | Type |
|---------|------|
| id | UUID |
| business_id | UUID |
| user_id | UUID |
| entity | VARCHAR |
| entity_id | UUID |
| action | VARCHAR |
| old_value | JSONB |
| new_value | JSONB |
| created_at | TIMESTAMP |

---

# Entity Relationships

```
Business
│
├── Users
├── Roles
├── Customers
├── Services
│      │
│      └── Slots
│              │
│              └── Bookings
│
├── Business Settings
├── WhatsApp Configuration
├── Notifications
└── Audit Logs
```

---

# Index Strategy

Create indexes on

```
business_id

customer_id

service_id

slot_id

booking_number

mobile_number

slot_date

status
```

Composite Indexes

```
business_id + mobile_number

business_id + slot_date

business_id + status
```

---

# Constraints

Examples

- Mobile Number Unique per Business
- Booking references valid Slot
- Booking references valid Customer
- Slot capacity cannot be negative
- Booking status must be valid

---

# Soft Delete

Important tables support

```
deleted_at
```

Instead of physical deletion.

Tables

- Services
- Customers
- Users
- Slots

---

# Performance Considerations

- Use UUID Primary Keys
- JSONB for conversation payload
- Proper indexing
- Connection pooling
- Pagination
- Query optimization

---

# Backup Strategy

- Daily Full Backup
- Hourly Incremental Backup
- Point-In-Time Recovery
- AWS RDS Snapshots

---

# Future Tables

Version 1.1

- staffs
- staff_services
- working_hours
- holidays

Version 1.2

- branches
- branch_services
- google_calendar_sync
- reminder_jobs

Version 2.0

- payments
- invoices
- coupons
- offers
- subscriptions
- ai_conversations
- reports

---

# Database Standards

- UUID for all primary keys
- Foreign key constraints enforced
- Use snake_case naming
- Store timestamps in UTC
- Never hardcode business-specific values
- Every business owns its own data
- Every table should support auditing where applicable

---

# Revision History

| Version | Date | Description |
|----------|------|-------------|
| 1.0 | July 2026 | Initial Database Design |
# Prisma Schema Design

**Document ID:** DB-002  
**Project:** Appointment Platform  
**Version:** 1.0  
**Status:** Draft

---

# Purpose

This document defines how the Appointment Platform database will be represented using Prisma ORM.

This is a design document only. The actual `schema.prisma` file will be created during development.

---

# Technology Stack

| Item | Value |
|------|-------|
| ORM | Prisma |
| Database | PostgreSQL |
| Language | TypeScript |
| Backend | Fastify |

---

# Design Principles

- UUID for all primary keys
- One Prisma model per database table
- Multi-tenant architecture
- Soft delete support
- Automatic timestamps
- Strong foreign key relationships
- No hardcoded business logic

---

# Naming Convention

## Model Names

Use PascalCase.

Example

```text
Business
User
Customer
Service
Booking
```

---

## Database Tables

Use snake_case plural.

Example

```text
businesses
users
customers
bookings
```

---

## Fields

Use camelCase in Prisma.

Example

```ts
firstName
lastName
businessId
createdAt
updatedAt
```

Database mapping

```ts
first_name
last_name
business_id
created_at
updated_at
```

using

```prisma
@map("first_name")
```

---

# Common Fields

Almost every model should contain:

```prisma
id

businessId

createdAt

updatedAt

deletedAt
```

---

# Enums

## BusinessStatus

```prisma
ACTIVE

INACTIVE

SUSPENDED
```

---

## UserRole

```prisma
OWNER

ADMIN

MANAGER

RECEPTIONIST
```

---

## BookingStatus

```prisma
PENDING

CONFIRMED

REJECTED

CANCELLED

COMPLETED

NO_SHOW
```

---

## SlotStatus

```prisma
AVAILABLE

FULL

BLOCKED

CANCELLED
```

---

## NotificationStatus

```prisma
PENDING

SENT

FAILED
```

---

# Prisma Models

## Business

Purpose

Represents a tenant.

Relationships

```text
Business

├── Users

├── Customers

├── Services

├── Bookings

├── Slots

├── Settings

└── WhatsApp Configuration
```

---

## BusinessSetting

One-to-One

```text
Business

↓

Business Setting
```

Contains

- Auto Approval
- Ask Customer Name
- Booking Window
- Cancellation Policy

---

## BusinessWhatsApp

Stores

- Phone Number
- Phone Number ID
- Verify Token
- Access Token

One business has one WhatsApp configuration.

---

## User

Belongs to Business.

Relations

```text
Business

↓

Users
```

---

## Role

Allows future Role-Based Access Control.

One business can define custom roles.

---

## Customer

Represents WhatsApp customer.

Rules

- Mobile number unique within business.
- Name optional.

Relations

```text
Business

↓

Customers

↓

Bookings
```

---

## ServiceCategory

Groups services.

Example

```text
Health

Beauty

Education

Consultation
```

---

## Service

Represents appointment service.

Example

```text
Hair Cut

Dental Checkup

Passport Consultation
```

Relations

```text
Category

↓

Services

↓

Slots
```

---

## Slot

Represents available appointment.

Relations

```text
Service

↓

Slots

↓

Bookings
```

---

## Booking

Core transaction table.

Relations

```text
Customer

↓

Booking

↓

Slot

↓

Service
```

---

## ConversationState

Stores WhatsApp progress.

Examples

```text
WAITING_SERVICE

WAITING_DATE

WAITING_SLOT

WAITING_NAME

CONFIRMATION
```

Payload stored as

```text
JSON
```

---

## Notification

Stores outgoing messages.

Types

```text
Confirmation

Reminder

Cancellation

Approval

Rejection
```

---

## AuditLog

Tracks

- Create
- Update
- Delete
- Login
- Configuration Changes

---

# Relationship Types

## One-to-One

```text
Business

↓

BusinessSetting
```

---

## One-to-Many

```text
Business

↓

Users
```

---

```text
Business

↓

Customers
```

---

```text
Business

↓

Services
```

---

```text
Service

↓

Slots
```

---

```text
Customer

↓

Bookings
```

---

## Many-to-One

```text
Booking

↓

Customer
```

---

```text
Booking

↓

Service
```

---

```text
Booking

↓

Slot
```

---

# Index Strategy

Use

```prisma
@@index([businessId])

@@index([status])

@@index([slotDate])

@@index([mobileNumber])
```

Composite indexes

```prisma
@@index([businessId,status])

@@index([businessId,mobileNumber])

@@index([businessId,slotDate])
```

---

# Unique Constraints

Business

```prisma
slug
```

---

User

```prisma
email
```

---

Customer

```prisma
businessId + mobileNumber
```

---

Booking

```prisma
bookingNumber
```

---

# Soft Delete Strategy

Supported using

```prisma
deletedAt DateTime?
```

No record should be permanently deleted unless required.

---

# JSON Fields

Use PostgreSQL JSONB.

Examples

Conversation payload

```json
{
  "selectedService": "Hair Cut",
  "selectedDate": "2026-07-20",
  "selectedSlot": "10:00 AM"
}
```

---

# Prisma Features

Use

```text
@id

@default(uuid())

@updatedAt

@relation

@map

@@map

@@index

@@unique
```

---

# Multi-Tenant Rules

Every business-owned model must contain

```prisma
businessId
```

Examples

```text
Customer

Service

Slot

Booking

Notification

Conversation

AuditLog
```

No query should return records from another business.

---

# Future Models

Version 1.1

```text
Staff

WorkingHours

Holiday

Branch
```

---

Version 1.2

```text
GoogleCalendar

ReminderJob

Offer

Coupon
```

---

Version 2.0

```text
Payment

Invoice

Subscription

AIConversation

Report
```

---

# Prisma Folder Structure

```text
prisma/

schema.prisma

migrations/

seed.ts

README.md
```

---

# Recommended Schema Organization

```text
Enums

↓

Models

↓

Relations

↓

Indexes

↓

Constraints
```

---

# Best Practices

- Use UUID primary keys.
- Use Prisma Migrate for all schema changes.
- Never edit production database manually.
- Use transactions for booking operations.
- Use optimistic locking where required.
- Validate all foreign keys.
- Store timestamps in UTC.
- Keep business logic outside Prisma models.

---

# Development Workflow

```text
Update Database Design
        ↓
Update Prisma Schema
        ↓
Generate Migration
        ↓
Review SQL
        ↓
Apply Migration
        ↓
Generate Prisma Client
        ↓
Implement APIs
```

---

# Revision History

| Version | Date | Description |
|----------|------|-------------|
| 1.0 | July 2026 | Initial Prisma Schema Design |
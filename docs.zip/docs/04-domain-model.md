# Domain Model

**Version:** 1.0

## Purpose

The Domain Model defines the core business entities of the Appointment Platform and their relationships. It serves as the foundation for the database, APIs, and business logic.

---

## Design Principles

- Multi-tenant architecture
- Configuration over hardcoding
- WhatsApp-first platform
- Extensible design
- No business-specific logic

---

## Core Entities

### Business

Represents a tenant using the platform.

Attributes:

- id
- name
- slug
- email
- phone
- timezone
- status

Relationships:

- Has many Users
- Has many Customers
- Has many Services
- Has many Slots
- Has many Bookings

---

### User

Represents a system user who manages a business.

Attributes:

- id
- business_id
- first_name
- last_name
- email
- password
- role

Relationships:

- Belongs to Business

---

### Customer

Represents an end user interacting through WhatsApp.

Attributes:

- id
- business_id
- mobile_number
- name
- language

Rules:

- Mobile number is unique within a business.
- Name may be optional based on business settings.

Relationships:

- Has many Bookings

---

### Service Category

Groups services.

Examples:

- Consultation
- Hair Care
- Dental

---

### Service

Represents a bookable service.

Attributes:

- id
- business_id
- category_id
- name
- duration
- price
- active

Relationships:

- Belongs to Category
- Has many Slots

---

### Slot

Represents an available appointment time.

Attributes:

- id
- business_id
- service_id
- date
- start_time
- end_time
- capacity

Relationships:

- Belongs to Service
- Has many Bookings

---

### Booking

Represents an appointment.

Attributes:

- id
- business_id
- customer_id
- service_id
- slot_id
- status

Status:

- Pending
- Confirmed
- Rejected
- Cancelled
- Completed
- No Show

---

### Conversation

Stores the WhatsApp conversation state.

Attributes:

- id
- business_id
- customer_id
- current_step
- payload
- expires_at

---

### Notification

Stores notifications sent to customers.

Types:

- Confirmation
- Reminder
- Cancellation
- Approval
- Rejection

---

## Entity Relationship

Business
├── Users
├── Customers
├── Services
│   └── Slots
│       └── Bookings
├── Settings
└── WhatsApp

---

## Future Entities

- Staff
- Branch
- Holiday Calendar
- Working Hours
- Offers
- Coupons
- Payments
- Google Calendar
- AI Assistant

---

## Revision History

| Version | Description |
|----------|-------------|
| 1.0 | Initial Version |